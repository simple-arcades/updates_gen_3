#!/bin/bash

# remote_support.sh (REVISED)
# Now supports SSH listening on ports 22 and 2222 simultaneously.

# Set the log flag. Set to "true" to enable logging; any other value disables logging.
ENABLE_LOGS="false"

LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/remote_access.log"
TIMER_PID_FILE="/home/pi/RetroPie/custom_scripts/logs/session_timer.pid"

log_action() {
    if [ "$ENABLE_LOGS" = "true" ]; then
        echo "$(date): $1" >> "$LOG_FILE"
    fi
}

check_dependencies() {
    if ! command -v lsof &> /dev/null; then
        log_action "lsof not found. Installing now."
        sudo apt-get update && sudo apt-get install -y lsof
        if [ $? -eq 0 ]; then
            log_action "lsof successfully installed."
        else
            log_action "Failed to install lsof. Please check the internet connection."
            whiptail --msgbox "Could not install a required tool (lsof). Please check your internet connection and try again." 20 60
            exit 1
        fi
    fi
}

fetch_external_ip() {
    curl -s https://api.ipify.org || echo "Unable to fetch external IP"
}

get_external_connection_info() {
    EXTERNAL_IP=$(fetch_external_ip)
    INTERNAL_IP=$(hostname -I | awk '{print $1}')
    # Inform the user to connect on port 2222
    echo -e "Internal IP: $INTERNAL_IP\nExternal IP: $EXTERNAL_IP\nPort: 2222"
}

start_disconnect_timer() {
    # Wait 30 minutes, then kill any SSHD connection on port 2222 (not 22)
    sleep $((30 * 60)) && {
        # Kill only SSH sessions listening/connected on port 2222
        for PID in $(sudo lsof -t -i TCP:2222); do
            sudo kill -9 "$PID"
            log_action "Auto‐terminated SSH PID $PID on port 2222 after 30 minutes."
        done
    } &
    echo $! > "$TIMER_PID_FILE"
}

stop_disconnect_timer() {
    if [ -f "$TIMER_PID_FILE" ]; then
        kill "$(cat "$TIMER_PID_FILE")" 2>/dev/null
        rm -f "$TIMER_PID_FILE"
    fi
}

start_support_session() {
    CONNECTION_INFO=$(get_external_connection_info)

    whiptail --msgbox "Your arcade's remote support session is ready:\n\n$CONNECTION_INFO\n\n\
Please forward external port 2222 to port 2222 on your Pi. Once your tech agent connects, you will see a confirmation. This session will close automatically after 30 minutes." 20 60

    start_disconnect_timer

    # Now check for ANY established SSH session on port 22 **or** port 2222
    if sudo lsof -i TCP:22 -i TCP:2222 | grep -q ESTABLISHED; then
        whiptail --msgbox "The tech agent is now connected to your arcade and may make adjustments.\n\n\
Please avoid playing games or turning off your arcade during this session. For safety, this session will close automatically after 30 minutes or you can close your session manually by pressing 'End Support Session'." 20 60
    else
        log_action "No active SSH connections detected on port 22 or 2222."
        whiptail --msgbox "No active connection detected. Please wait while your tech agent connects via port 2222." 20 60
    fi
}

disconnect_support_session() {
    stop_disconnect_timer

    # Find and kill any SSHD processes with an established TCP on port 2222
    ACTIVE_PIDS=$(sudo lsof -t -i TCP:2222)
    if [ -n "$ACTIVE_PIDS" ]; then
        for PID in $ACTIVE_PIDS; do
            sudo kill -9 "$PID"
            log_action "Terminated SSH session PID $PID on port 2222."
        done
    else
        log_action "No active SSH sessions on port 2222 to terminate."
    fi

    # Restart the SSH service so it continues listening on both ports
    sudo systemctl restart ssh
    log_action "SSH service restarted (listening on ports 22 & 2222)."

    whiptail --msgbox "The remote support session has ended. The tech agent is now disconnected.\n\n\
Thank you for allowing remote support. Press 'OK' to return to the main menu." 20 60
}

show_port_forwarding_instructions() {
    CONNECTION_INFO=$(get_external_connection_info)

    whiptail --msgbox "To enable remote support, please do the following on your router:\n\n\
1. Open your router’s admin page.\n\
2. Create (or edit) a port‐forwarding rule:\n\
   - External (WAN) Port: 2222\n\
   - Internal (LAN) IP: $(hostname -I | awk '{print $1}')\n\
   - Internal (LAN) Port: 2222\n\
   - Protocol: TCP\n\
3. Share the following details with your tech agent:\n\n$CONNECTION_INFO" 20 60
}

main_menu() {
    check_dependencies

    whiptail --title "Simple Arcades Remote Support Tool" --msgbox "Welcome to the Simple Arcades Remote Support Tool.\n\n\
This tool allows our tech support team to remotely troubleshoot your arcade. \
Only start a remote session if you have already spoken with a tech agent.\n\n\
For security, unsolicited connections are not monitored." 20 60

    while true; do
        CHOICE=$(whiptail --title "Remote Support Menu" --menu "Choose an option:" 20 60 5 \
        "1" "Start Remote Support Session" \
        "2" "End Support Session" \
        "3" "Port Forwarding Instructions" \
        "4" "View Session Logs" \
        "5" "Exit" 3>&1 1>&2 2>&3)

        case $CHOICE in
            1) start_support_session ;;
            2) disconnect_support_session ;;
            3) show_port_forwarding_instructions ;;
            4) whiptail --textbox "$LOG_FILE" 20 60 ;;
            5) stop_disconnect_timer; break ;;
            *) whiptail --msgbox "Invalid option. Please try again." 10 40 ;;
        esac
    done
}

main_menu