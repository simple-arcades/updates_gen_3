sudo python3 /home/pi/RetroPie/custom_scripts/show_hide_systems.py 2>/dev/null
