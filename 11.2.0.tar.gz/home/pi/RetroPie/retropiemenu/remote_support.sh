#!/usr/bin/env bash
#===============================================================================
# remote_support.sh - Simple Arcades Remote Support (Alpha -> Beta hardening) - v1.2
#
# Purpose:
#   Help a customer put their arcade into a temporary, time-limited "support"
#   mode so a technician can connect (typically via WinSCP/SFTP over SSH).
#
# Notes:
#   - This tool does NOT create port-forwarding automatically; it guides the user.
#   - For security, it creates a temporary "support" user with a random password
#     and removes it automatically after the session timeout.
#
# Version: 1.1
#===============================================================================

set -u

# ---------------------------- Config / Defaults -------------------------------
SUPPORT_PORT="2222"
SESSION_MINUTES_DEFAULT="60"
SESSION_MINUTES="$SESSION_MINUTES_DEFAULT"

TEMP_USER="support"
STATE_DIR="/var/run/remote_support"
STATE_FILE="${STATE_DIR}/session.env"
LOG_DIR="/var/log/simple_arcades"
LOG_FILE="${LOG_DIR}/remote_support.log"
PUBLIC_CHECK_TS_FILE="${LOG_DIR}/.last_pub_check.ts"
PUBLIC_CHECK_REFRESH_SECS="300"

# Commands (prefer absolute where practical)
CURL_BIN="/usr/bin/curl"
AWK_BIN="/usr/bin/awk"
SED_BIN="/bin/sed"
GREP_BIN="/bin/grep"
MKDIR_BIN="/bin/mkdir"
DATE_BIN="/bin/date"
SLEEP_BIN="/bin/sleep"
LSOF_BIN="/usr/bin/lsof"
SYSTEMCTL_BIN="/bin/systemctl"
USERADD_BIN="/usr/sbin/useradd"
USERDEL_BIN="/usr/sbin/userdel"
CHPASSWD_BIN="/usr/sbin/chpasswd"
ID_BIN="/usr/bin/id"
HOSTNAME_BIN="/bin/hostname"
TOUCH_BIN="/usr/bin/touch"
CHMOD_BIN="/bin/chmod"

# ------------------------------- Utilities ------------------------------------
log() {
  local msg="$1"
  $MKDIR_BIN -p "$LOG_DIR" 2>/dev/null || true
  printf "[%s] %s\n" "$($DATE_BIN '+%Y-%m-%d %H:%M:%S')" "$msg" >> "$LOG_FILE" 2>/dev/null || true
}

have_exec() {
  local p="$1"
  [[ -x "$p" ]]
}

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

ui_box_size() {
  local rows cols
  rows="$(stty size 2>/dev/null | $AWK_BIN '{print $1}')"
  cols="$(stty size 2>/dev/null | $AWK_BIN '{print $2}')"
  [[ -z "${rows:-}" ]] && rows=24
  [[ -z "${cols:-}" ]] && cols=80
  echo "$rows $cols"
}

is_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]]; }

need_sudo() {
  # We rely on passwordless sudo in RetroPie (typical). If not available, warn.
  if sudo -n true >/dev/null 2>&1; then
    return 0
  fi
  whiptail --title "Remote Support" --msgbox \
"Administrator permission is required (sudo).\n\nThis system does not appear to allow passwordless sudo.\n\nPlease run this tool from the RetroPie menu (recommended), or enable sudo for the current user." \
  12 70
  return 1
}

safe_mkdir_root() {
  local d="$1"
  sudo -n $MKDIR_BIN -p "$d" >/dev/null 2>&1 || return 1
  return 0
}

# ----------------------------- Network Helpers --------------------------------
fetch_external_ip() {
  # Best-effort public IP lookup (two sources).
  local ip=""
  if have_exec "$CURL_BIN"; then
    ip="$($CURL_BIN -fsS --max-time 4 https://api.ipify.org 2>/dev/null || true)"
    if [[ -z "$ip" ]]; then
      ip="$($CURL_BIN -fsS --max-time 4 https://ifconfig.me/ip 2>/dev/null || true)"
    fi
  fi
  echo "$ip"
}

fetch_internal_ip() {
  local ip=""
  ip="$($HOSTNAME_BIN -I 2>/dev/null | $AWK_BIN '{print $1}')"
  echo "$ip"
}

sshd_listening_on_port() {
  # True if sshd is listening on SUPPORT_PORT.
  sudo -n "$LSOF_BIN" -iTCP:"$SUPPORT_PORT" -sTCP:LISTEN -nP 2>/dev/null | $GREP_BIN -qi "sshd"
}

check_public_port_status() {
  # Best-effort public port reachability check using check-host.net API.
  # OPEN if ANY probe node succeeds.
  # CLOSED if ALL finished and none succeeded.
  # UNKNOWN if API fails or results never complete in time.
  local pub_ip="$1"
  local port="$2"
  local request_id=""
  local result=""
  local attempts=0
  local max_attempts=15

  [[ -z "$pub_ip" ]] && echo "UNKNOWN" && return 0
  [[ -z "$port" ]] && echo "UNKNOWN" && return 0
  have_exec "$CURL_BIN" || { echo "UNKNOWN"; return 0; }

  request_id="$($CURL_BIN -fsS --max-time 6 "https://check-host.net/check-tcp?host=${pub_ip}:${port}&max_nodes=3" 2>/dev/null | $GREP_BIN -oE '\"request_id\":\"[^\"]+\"' | $SED_BIN 's/\"request_id\":\"//;s/\"//')"
  [[ -z "$request_id" ]] && echo "UNKNOWN" && return 0

  # Poll until no "null" (all nodes finished), or any success shows "address".
  while [[ $attempts -lt $max_attempts ]]; do
    result="$($CURL_BIN -fsS --max-time 6 "https://check-host.net/check-result/${request_id}" 2>/dev/null || true)"

    if echo "$result" | $GREP_BIN -q '"address"'; then
      echo "OPEN"
      return 0
    fi

    # If any nodes still running, JSON includes nulls.
    if echo "$result" | $GREP_BIN -q '"null"'; then
      $SLEEP_BIN 1
      attempts=$((attempts+1))
      continue
    fi

    # Finished (no nulls) and no success.
    echo "CLOSED"
    return 0
  done

  echo "UNKNOWN"
  return 0
}

cached_public_status() {
  local now last
  now="$($DATE_BIN +%s)"
  last="0"
  [[ -f "$PUBLIC_CHECK_TS_FILE" ]] && last="$(cat "$PUBLIC_CHECK_TS_FILE" 2>/dev/null || echo 0)"

  if [[ $((now - last)) -lt "$PUBLIC_CHECK_REFRESH_SECS" ]]; then
    cat "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || echo "UNKNOWN"
    return 0
  fi

  echo "$now" > "$PUBLIC_CHECK_TS_FILE" 2>/dev/null || true
  local ext_ip status
  ext_ip="$(fetch_external_ip)"
  status="$(check_public_port_status "$ext_ip" "$SUPPORT_PORT")"
  echo "$status" > "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || true
  echo "$status"
}

force_refresh_public_status() {
  rm -f "$PUBLIC_CHECK_TS_FILE" "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || true
  cached_public_status >/dev/null 2>&1 || true
}

# ------------------------------ Session State ---------------------------------
load_state() {
  [[ -f "$STATE_FILE" ]] || return 1
  # shellcheck disable=SC1090
  source "$STATE_FILE"
  return 0
}

save_state() {
  safe_mkdir_root "$STATE_DIR" || return 1
  sudo -n $TOUCH_BIN "$STATE_FILE" >/dev/null 2>&1 || return 1
  sudo -n $CHMOD_BIN 600 "$STATE_FILE" >/dev/null 2>&1 || true
  sudo -n bash -c "cat > '$STATE_FILE' <<'EOF'
TEMP_USER=${TEMP_USER}
TEMP_PASS=${TEMP_PASS}
SUPPORT_PORT=${SUPPORT_PORT}
SESSION_START=${SESSION_START}
SESSION_EXPIRES=${SESSION_EXPIRES}
SESSION_MINUTES=${SESSION_MINUTES}
EOF" >/dev/null 2>&1 || return 1
  return 0
}

clear_state() {
  sudo -n rm -f "$STATE_FILE" >/dev/null 2>&1 || true
}

session_active() {
  load_state || return 1
  local now
  now="$($DATE_BIN +%s)"
  [[ "${SESSION_EXPIRES:-0}" -gt "$now" ]] || return 1
  return 0
}

session_expired() {
  load_state || return 0
  local now
  now="$($DATE_BIN +%s)"
  [[ "${SESSION_EXPIRES:-0}" -le "$now" ]]
}

# ----------------------------- User Management --------------------------------
gen_temp_pass() {
  # Readable random password (no spaces).
  # Example: 10 chars A-Z a-z 0-9
  tr -dc 'A-Za-z0-9' </dev/urandom 2>/dev/null | head -c 10
}

support_user_exists() {
  sudo -n "$ID_BIN" "$TEMP_USER" >/dev/null 2>&1
}

delete_support_user() {
  if support_user_exists; then
    sudo -n "$USERDEL_BIN" -r "$TEMP_USER" >/dev/null 2>&1 || sudo -n "$USERDEL_BIN" "$TEMP_USER" >/dev/null 2>&1 || true
    log "Deleted support user '$TEMP_USER'."
  fi
}

create_support_user() {
  TEMP_PASS="$(gen_temp_pass)"
  if [[ -z "$TEMP_PASS" ]]; then
    TEMP_PASS="support123"
  fi

  sudo -n "$USERADD_BIN" -m -s /bin/bash "$TEMP_USER" >/dev/null 2>&1 || return 1
  echo "${TEMP_USER}:${TEMP_PASS}" | sudo -n "$CHPASSWD_BIN" >/dev/null 2>&1 || return 1
  log "Created support user '$TEMP_USER' with temporary password."
  return 0
}

ensure_support_user_for_session() {
  # If an active session exists, reuse user and password from state.
  if session_active; then
    TEMP_PASS="${TEMP_PASS:-}"
    if [[ -n "$TEMP_PASS" ]] && support_user_exists; then
      return 0
    fi
  fi

  # If user exists but no active state, treat as stale and recreate.
  if support_user_exists; then
    delete_support_user
  fi

  create_support_user || return 1
  return 0
}

# ------------------------------ Port Forwarding -------------------------------
show_port_forwarding_instructions() {
  local internal_ip
  internal_ip="$(fetch_internal_ip)"

  whiptail --title "Port Forwarding Required" --msgbox \
"To allow a technician to connect, your router must forward TCP port ${SUPPORT_PORT} to this arcade.\n\nSteps (general):\n - Open your router settings (usually in a web browser).\n - Find Port Forwarding / NAT settings.\n - Add a rule: External TCP ${SUPPORT_PORT} -> Internal ${internal_ip}:${SUPPORT_PORT}\n - Save/apply changes.\n\nIf you use a modem/router combo, you may need to set up forwarding there, too.\n\nTip: For best results, connect the arcade directly to the TV/monitor (avoid HDMI splitters/AVRs while troubleshooting)." \
  20 74
}

# ------------------------------ Session Control -------------------------------
disconnect_now() {
  delete_support_user
  clear_state
  log "Support session ended."
}

start_disconnect_timer() {
  local seconds="$1"
  local cmd
  cmd="sleep ${seconds}; sudo -n ${USERDEL_BIN} -r ${TEMP_USER} >/dev/null 2>&1 || sudo -n ${USERDEL_BIN} ${TEMP_USER} >/dev/null 2>&1; sudo -n rm -f '${STATE_FILE}' >/dev/null 2>&1; echo \"[\$(${DATE_BIN} '+%Y-%m-%d %H:%M:%S')] Support session auto-ended (timeout).\" >> '${LOG_FILE}'"
  nohup bash -c "$cmd" >/dev/null 2>&1 &
}

connected_any() {
  # True if any SSH sessions are established to sshd.
  sudo -n "$LSOF_BIN" -nP -iTCP -sTCP:ESTABLISHED 2>/dev/null | $GREP_BIN -qi "sshd"
}

# ------------------------------- UI Content -----------------------------------
render_connection_card() {
  local ext_ip int_ip status ssh_listen
  ext_ip="$(fetch_external_ip)"
  int_ip="$(fetch_internal_ip)"
  ssh_listen="NO"
  if sshd_listening_on_port; then ssh_listen="YES"; fi

  local pub_status="UNKNOWN"
  if [[ "$ssh_listen" == "YES" ]]; then
    pub_status="$(cached_public_status)"
  fi

  cat <<EOF
REMOTE SUPPORT IS ENABLED

Account:
  Username: ${TEMP_USER}
  Password: ${TEMP_PASS}

Connection:
  Public IP: ${ext_ip:-Unknown}
  Internal IP: ${int_ip:-Unknown}
  SSH Port: ${SUPPORT_PORT}
  SSH Listening: ${ssh_listen}
  Port Status (best-effort): ${pub_status}

Tips:
  - The technician usually connects using SFTP/SSH (WinSCP).
  - If Port Status shows CLOSED/UNKNOWN, check router port forwarding.

Your arcade is now ready for your technician.
EOF
}

help_text() {
  cat <<'EOF'
SIMPLE ARCADES REMOTE SUPPORT

What this does:
  - Creates a temporary "support" login so a technician can connect.
  - Shows connection details you can share with your technician.
  - Automatically disables the support login after the timeout.

What you need:
  - The arcade must be connected to the internet (Wi-Fi or Ethernet).
  - Your router must allow inbound connections on the support port.

Port forwarding:
  - This tool can NOT change your router settings for you.
  - You may need to forward TCP port 2222 to this arcade.

Common issues:
  - CGNAT (some ISPs) can prevent inbound connections.
  - A second router/modem may require forwarding in BOTH devices.
  - Firewalls can block the port.

Security:
  - The support password is random each time.
  - Only enable support when a technician asks you to.
  - End the session when finished.
EOF
}


show_intro() {
  # Short, user-friendly intro shown once per run.
  whiptail --title "Simple Arcades Remote Support" --msgbox "Welcome to Simple Arcades Remote Support.\n\nThis tool allows a Simple Arcades technician to connect to your arcade for troubleshooting.\n\nOnly enable a support session when a technician asks you to.\n\nBefore you start:\n - Make sure your arcade is online (Wi-Fi or Ethernet)\n - Set up router port forwarding for TCP port 2222 (see instructions)\n\nPress OK to continue." 18 74
}

# ------------------------------- Main Flow ------------------------------------
preflight() {
  local missing=()

  # Required binaries
  for b in "$CURL_BIN" "$AWK_BIN" "$SED_BIN" "$GREP_BIN" "$MKDIR_BIN" "$DATE_BIN" "$SLEEP_BIN" "$LSOF_BIN" "$ID_BIN" "$HOSTNAME_BIN" "$USERADD_BIN" "$USERDEL_BIN" "$CHPASSWD_BIN" "$TOUCH_BIN" "$CHMOD_BIN"; do
    have_exec "$b" || missing+=("$b")
  done

  have_cmd whiptail || missing+=("whiptail")

  if [[ ${#missing[@]} -gt 0 ]]; then
    whiptail --title "Remote Support" --msgbox \
"Missing required tools:\n\n$(printf '%s\n' "${missing[@]}")\n\nPlease contact Simple Arcades support." \
    18 70
    return 1
  fi

  need_sudo || return 1
  return 0
}


ask_session_minutes() {
  local input
  input="$(whiptail --title "Session Duration" --inputbox \
"How long should remote support stay enabled? (minutes)\n\nRecommended: 60\nRange: 5 to 240" \
10 70 "$SESSION_MINUTES_DEFAULT" 3>&1 1>&2 2>&3)" || return 1

  # Sanitize: keep digits only
  input="${input//[^0-9]/}"
  [[ -z "$input" ]] && return 1

  if (( input < 5 )); then input=5; fi
  if (( input > 240 )); then input=240; fi

  SESSION_MINUTES="$input"
  return 0
}

start_support_session() {
  local now expires
  now="$($DATE_BIN +%s)"
  ask_session_minutes || return 0

  expires="$((now + SESSION_MINUTES*60))"

  ensure_support_user_for_session || {
    whiptail --title "Remote Support" --msgbox "Failed to create the support account.\n\nPlease contact Simple Arcades support." 12 70
    log "ERROR: Failed to create support user."
    return 1
  }

  TEMP_PASS="${TEMP_PASS:-${TEMP_PASS}}"
  SESSION_START="$now"
  SESSION_EXPIRES="$expires"

  save_state || {
    whiptail --title "Remote Support" --msgbox "Failed to save session state.\n\nPlease contact Simple Arcades support." 12 70
    log "ERROR: Failed to save state."
    return 1
  }

  # Ensure sshd is listening before asking for port forwarding.
  if ! sshd_listening_on_port; then
    whiptail --title "Remote Support" --msgbox \
"SSH is not listening on port ${SUPPORT_PORT}.\n\nPlease ensure /etc/ssh/sshd_config contains:\n  Port 22\n  Port ${SUPPORT_PORT}\n\nThen restart SSH and try again." \
    16 74
    log "ERROR: sshd not listening on ${SUPPORT_PORT}."
    return 1
  fi

  show_port_forwarding_instructions

  # Start auto-disconnect timer (best effort).
  start_disconnect_timer "$((SESSION_MINUTES*60))"
  log "Support session started. Expires in ${SESSION_MINUTES} minutes."

  local card
  card="$(render_connection_card)"
  whiptail --title "Remote Support Enabled" --msgbox "$card" 22 74

  live_session_menu
}

live_session_menu() {
  while true; do
    if session_expired; then
      disconnect_now
      whiptail --title "Remote Support" --msgbox "Support session ended (timeout)." 10 60
      return 0
    fi

    local choice
    choice="$(whiptail --title "Remote Support (Active)" --menu \
"Choose an option:" 18 74 6 \
"1" "Show connection details" \
"2" "Refresh port status (best-effort)" \
"3" "End support session now" \
"4" "Back to main menu" \
3>&1 1>&2 2>&3)" || return 0

    case "$choice" in
      1)
        local card
        card="$(render_connection_card)"
        whiptail --title "Connection Details" --msgbox "$card" 22 74
        ;;
      2)
        force_refresh_public_status
        whiptail --title "Remote Support" --msgbox "Status refreshed." 8 40
        ;;
      3)
        if whiptail --title "Confirm" --yesno "End the support session now?" 10 50; then
          disconnect_now
          whiptail --title "Remote Support" --msgbox "Support session ended." 8 40
          return 0
        fi
        ;;
      4)
        return 0
        ;;
    esac
  done
}

test_connectivity() {
  local msg=""
  if sshd_listening_on_port; then
    msg+="SSH is listening on port ${SUPPORT_PORT}: YES\n"
  else
    msg+="SSH is listening on port ${SUPPORT_PORT}: NO\n"
  fi

  local ext_ip
  ext_ip="$(fetch_external_ip)"
  msg+="Public IP detected: ${ext_ip:-Unknown}\n"

  whiptail --title "Connectivity Test" --msgbox "$msg" 12 70
}

main_menu() {
  local choice
  while true; do
    local status_line="Status: Inactive"
    if session_active; then
      local now left
      now="$($DATE_BIN +%s)"
      left=$(( (SESSION_EXPIRES - now + 59) / 60 ))
      if (( left < 0 )); then left=0; fi
      status_line="Status: Active (about ${left} min left)"
    fi

    choice="$(whiptail --title "Simple Arcades Remote Support" --menu \
"${status_line}\n\nSelect an option:" 20 74 8 \
"1" "Port forwarding instructions" \
"2" "Connectivity test" \
"3" "Start support session" \
"4" "Show connection details (if active)" \
"5" "End support session (if active)" \
"6" "Help" \
"7" "Exit" \
3>&1 1>&2 2>&3)" || exit 0

    case "$choice" in
      1)
        show_port_forwarding_instructions
        ;;
      2)
        test_connectivity
        ;;
      3)
        start_support_session
        ;;
      4)
        show_connection_details
        ;;
      5)
        end_support_session
        ;;
      6)
        show_help
        ;;
      7)
        exit 0
        ;;
      *)
        break
        ;;
    esac
  done
}

main() {
  preflight || exit 1

  # Best-effort cleanup of stale support user if state is missing/expired.
  if support_user_exists && ! session_active; then
    # If state file is missing or expired, remove the user to avoid leaving access open.
    if ! load_state; then
      delete_support_user
    else
      if session_expired; then
        delete_support_user
        clear_state
      fi
    fi
  fi

  show_intro

  main_menu
}

main "$@"
