#!/usr/bin/env python3
"""
restart_emulationstation.py

Sends an F4 keypress to EmulationStation via /dev/uinput.

Logging:
- Set ENABLE_LOG = True/False below (like your other scripts), OR
- Create the file LOG_TOGGLE_FILE to force-enable logging without editing this script.
"""

import os
import sys
import time
import traceback
import getpass

import uinput


# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
ENABLE_LOG = False  # Set to False to disable logging
LOG_FILE = "/home/pi/RetroPie/custom_scripts/logs/restart_es_debug.log"

# If this file exists, logging is forced ON (even if ENABLE_LOG is False)
LOG_TOGGLE_FILE = "/home/pi/RetroPie/custom_scripts/logs/restart_es_debug.enabled"

# If True, truncate log at the start of each run (like your onend.sh behavior)
TRUNCATE_LOG_ON_START = False

# Timing (seconds)
PRE_DEVICE_DELAY = 1.0
POST_DEVICE_DELAY = 1.0
POST_KEY_DELAY = 1.0


# -----------------------------------------------------------------------------
# Logging helpers
# -----------------------------------------------------------------------------
def _logging_enabled() -> bool:
    if os.path.exists(LOG_TOGGLE_FILE):
        return True
    return bool(ENABLE_LOG)


def _ensure_log_dir() -> None:
    log_dir = os.path.dirname(LOG_FILE)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)


def log(msg: str) -> None:
    if not _logging_enabled():
        return
    try:
        _ensure_log_dir()
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{ts} [restart_emulationstation.py] {msg}\n")
    except Exception:
        # Never let logging failures break the restart action
        pass


# -----------------------------------------------------------------------------
# Sanity checks
# -----------------------------------------------------------------------------
def sanity_checks() -> None:
    uinput_path = "/dev/uinput"

    if not os.path.exists(uinput_path):
        raise RuntimeError(f"{uinput_path} does not exist")

    # Check read/write access for the current user
    if not (os.access(uinput_path, os.R_OK) and os.access(uinput_path, os.W_OK)):
        # Helpful context for diagnosing perms/groups
        st = os.stat(uinput_path)
        raise PermissionError(
            f"No RW access to {uinput_path}. "
            f"mode={oct(st.st_mode)} uid={st.st_uid} gid={st.st_gid} "
            f"user={getpass.getuser()} euid={os.geteuid()} egid={os.getegid()}"
        )


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main() -> int:
    if _logging_enabled() and TRUNCATE_LOG_ON_START:
        try:
            _ensure_log_dir()
            with open(LOG_FILE, "w", encoding="utf-8") as f:
                f.write("")
        except Exception:
            pass

    log("START")

    try:
        sanity_checks()
        log("Sanity checks OK (/dev/uinput RW)")

        time.sleep(PRE_DEVICE_DELAY)

        # Create uinput device capable of sending F4
        events = (uinput.KEY_F4,)
        with uinput.Device(events) as device:
            time.sleep(POST_DEVICE_DELAY)
            device.emit_click(uinput.KEY_F4)
            time.sleep(POST_KEY_DELAY)

        log("SENT_F4")
        log("DONE")
        return 0

    except Exception:
        log("ERROR")
        log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    sys.exit(main())