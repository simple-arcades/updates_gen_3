#!/usr/bin/env bash
#
# /home/pi/RetroPie/custom_scripts/launch_savestate.sh
#
# Called by EmulationStation for the "savestates" system, passing a .stateX.entry file.
# This script:
#   - Detects which slot X from the filename
#   - Instructs runcommand to use the corresponding "retroarch-slotX" line in
#     /opt/retropie/configs/savestates/emulators.cfg
#   - That line has "--entryslot X" so RetroArch auto-loads the correct save state slot.

ENTRYFILE="$1"

if [[ -z "$ENTRYFILE" || ! -f "$ENTRYFILE" ]]; then
    echo "Error: Invalid or missing .entry file: '$ENTRYFILE'"
    exit 1
fi

# Example: "Super Mario Bros (USA).state2.entry" => slot_number=2
BASENAME="$(basename "$ENTRYFILE")"

# Extract the slot. We look for: ".stateX.entry" => X can be 0..9 or more.
# We'll use a simple grep pattern:
SLOT_NUMBER="$(echo "$BASENAME" | grep -oP '(?<=\.state)\d+(?=\.entry$)')"

if [[ -z "$SLOT_NUMBER" ]]; then
    # If we can't parse it, default to slot1
    SLOT_NUMBER="1"
fi

# The matching line in /opt/retropie/configs/savestates/emulators.cfg
# is e.g. "retroarch-slot2"
EMULATOR_NAME="retroarch-slot${SLOT_NUMBER}"

#echo "Launching Save State entry: $ENTRYFILE"
#echo "Detected slot: $SLOT_NUMBER => using emulator: $EMULATOR_NAME"

# Now call runcommand for system=savestates, using the .entry file as the "ROM"
exec /opt/retropie/supplementary/runcommand/runcommand.sh 0 _SYS_ savestates "$ENTRYFILE" --emulator "$EMULATOR_NAME"
