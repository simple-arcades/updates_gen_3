#!/usr/bin/env bash
#===============================================================================
# remote_support.sh - Simple Arcades Remote Support - v2.0
#
# Purpose:
#   Help a customer put their arcade into a temporary, time-limited "support"
#   mode so a technician can connect (typically via WinSCP/SFTP over SSH).
#
# Changelog v2.0:
#   - Added sudo access for support user
#   - Added "Check if technician is connected" feature
#   - Added "Extend session" feature
#   - Added "Allow Reconnect After Restart" mode for multi-reboot troubleshooting
#   - Added loading indicator for slow port checks
#   - Improved customer-facing language (beginner-friendly)
#   - Fixed missing functions (show_connection_details, end_support_session, show_help)
#   - Changed log directory to /home/pi/RetroPie/custom_scripts/logs/
#
#===============================================================================

set -u

# ---------------------------- Config / Defaults -------------------------------
SUPPORT_PORT="2222"
SESSION_MINUTES_DEFAULT="60"
SESSION_MINUTES="$SESSION_MINUTES_DEFAULT"

TEMP_USER="support"
STATE_DIR="/var/run/remote_support"
STATE_FILE="${STATE_DIR}/session.env"
LOG_DIR="/home/pi/RetroPie/custom_scripts/logs"
LOG_FILE="${LOG_DIR}/remote_support.log"
PUBLIC_CHECK_TS_FILE="${LOG_DIR}/.last_pub_check.ts"
PUBLIC_CHECK_REFRESH_SECS="300"

# Reboot-safe mode service
REBOOT_SERVICE="/etc/systemd/system/sa_remote_restore.service"

# Commands (prefer absolute where practical)
CURL_BIN="/usr/bin/curl"
AWK_BIN="/usr/bin/awk"
SED_BIN="/bin/sed"
GREP_BIN="/bin/grep"
MKDIR_BIN="/bin/mkdir"
DATE_BIN="/bin/date"
SLEEP_BIN="/bin/sleep"
LSOF_BIN="/usr/bin/lsof"
SYSTEMCTL_BIN="/bin/systemctl"
USERADD_BIN="/usr/sbin/useradd"
USERDEL_BIN="/usr/sbin/userdel"
CHPASSWD_BIN="/usr/sbin/chpasswd"
ID_BIN="/usr/bin/id"
HOSTNAME_BIN="/bin/hostname"
TOUCH_BIN="/usr/bin/touch"
CHMOD_BIN="/bin/chmod"

# ------------------------------- Utilities ------------------------------------
log() {
  local msg="$1"
  $MKDIR_BIN -p "$LOG_DIR" 2>/dev/null || true
  printf "[%s] %s\n" "$($DATE_BIN '+%Y-%m-%d %H:%M:%S')" "$msg" >> "$LOG_FILE" 2>/dev/null || true
}

have_exec() {
  local p="$1"
  [[ -x "$p" ]]
}

have_cmd() {
  command -v "$1" >/dev/null 2>&1
}

ui_box_size() {
  local rows cols
  rows="$(stty size 2>/dev/null | $AWK_BIN '{print $1}')"
  cols="$(stty size 2>/dev/null | $AWK_BIN '{print $2}')"
  [[ -z "${rows:-}" ]] && rows=24
  [[ -z "${cols:-}" ]] && cols=80
  echo "$rows $cols"
}

is_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]]; }

need_sudo() {
  if sudo -n true >/dev/null 2>&1; then
    return 0
  fi
  whiptail --title "Remote Support" --msgbox \
"This tool needs administrator permission to work.\n\nPlease run this from the RetroPie menu, or contact Simple Arcades support if you see this message." \
  12 70
  return 1
}

safe_mkdir_root() {
  local d="$1"
  sudo -n $MKDIR_BIN -p "$d" >/dev/null 2>&1 || return 1
  return 0
}

# ----------------------------- Network Helpers --------------------------------
fetch_external_ip() {
  local ip=""
  if have_exec "$CURL_BIN"; then
    ip="$($CURL_BIN -fsS --max-time 4 https://api.ipify.org 2>/dev/null || true)"
    if [[ -z "$ip" ]]; then
      ip="$($CURL_BIN -fsS --max-time 4 https://ifconfig.me/ip 2>/dev/null || true)"
    fi
  fi
  echo "$ip"
}

fetch_internal_ip() {
  local ip=""
  ip="$($HOSTNAME_BIN -I 2>/dev/null | $AWK_BIN '{print $1}')"
  echo "$ip"
}

sshd_listening_on_port() {
  sudo -n "$LSOF_BIN" -iTCP:"$SUPPORT_PORT" -sTCP:LISTEN -nP 2>/dev/null | $GREP_BIN -qi "sshd"
}

check_public_port_status() {
  local pub_ip="$1"
  local port="$2"
  local request_id=""
  local result=""
  local attempts=0
  local max_attempts=15

  [[ -z "$pub_ip" ]] && echo "UNKNOWN" && return 0
  [[ -z "$port" ]] && echo "UNKNOWN" && return 0
  have_exec "$CURL_BIN" || { echo "UNKNOWN"; return 0; }

  request_id="$($CURL_BIN -fsS --max-time 6 "https://check-host.net/check-tcp?host=${pub_ip}:${port}&max_nodes=3" 2>/dev/null | $GREP_BIN -oE '\"request_id\":\"[^\"]+\"' | $SED_BIN 's/\"request_id\":\"//;s/\"//')"
  [[ -z "$request_id" ]] && echo "UNKNOWN" && return 0

  while [[ $attempts -lt $max_attempts ]]; do
    result="$($CURL_BIN -fsS --max-time 6 "https://check-host.net/check-result/${request_id}" 2>/dev/null || true)"

    if echo "$result" | $GREP_BIN -q '"address"'; then
      echo "OPEN"
      return 0
    fi

    if echo "$result" | $GREP_BIN -q '"null"'; then
      $SLEEP_BIN 1
      attempts=$((attempts+1))
      continue
    fi

    echo "CLOSED"
    return 0
  done

  echo "UNKNOWN"
  return 0
}

cached_public_status() {
  local now last
  now="$($DATE_BIN +%s)"
  last="0"
  [[ -f "$PUBLIC_CHECK_TS_FILE" ]] && last="$(cat "$PUBLIC_CHECK_TS_FILE" 2>/dev/null || echo 0)"

  if [[ $((now - last)) -lt "$PUBLIC_CHECK_REFRESH_SECS" ]]; then
    cat "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || echo "UNKNOWN"
    return 0
  fi

  echo "$now" > "$PUBLIC_CHECK_TS_FILE" 2>/dev/null || true
  local ext_ip status
  ext_ip="$(fetch_external_ip)"
  status="$(check_public_port_status "$ext_ip" "$SUPPORT_PORT")"
  echo "$status" > "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || true
  echo "$status"
}

force_refresh_public_status() {
  rm -f "$PUBLIC_CHECK_TS_FILE" "${LOG_DIR}/.last_pub_check.status" 2>/dev/null || true
  cached_public_status >/dev/null 2>&1 || true
}

check_port_with_loading() {
  local now last
  now="$($DATE_BIN +%s)"
  last="0"
  [[ -f "$PUBLIC_CHECK_TS_FILE" ]] && last="$(cat "$PUBLIC_CHECK_TS_FILE" 2>/dev/null || echo 0)"

  if [[ $((now - last)) -lt "$PUBLIC_CHECK_REFRESH_SECS" ]]; then
    cached_public_status
    return 0
  fi

  (
    for i in {1..15}; do
      echo "$((i * 6))"
      sleep 1
    done
    echo "100"
  ) | whiptail --gauge "Checking if your arcade is reachable from the internet...\n\nThis may take 10-15 seconds." 10 70 0 &
  
  local gauge_pid=$!
  local status
  status="$(cached_public_status)"
  
  kill $gauge_pid 2>/dev/null || true
  wait $gauge_pid 2>/dev/null || true
  
  echo "$status"
}

# ------------------------------ Session State ---------------------------------
load_state() {
  [[ -f "$STATE_FILE" ]] || return 1
  source "$STATE_FILE"
  return 0
}

save_state() {
  safe_mkdir_root "$STATE_DIR" || return 1
  sudo -n $TOUCH_BIN "$STATE_FILE" >/dev/null 2>&1 || return 1
  sudo -n $CHMOD_BIN 600 "$STATE_FILE" >/dev/null 2>&1 || true
  sudo -n bash -c "cat > '$STATE_FILE' <<'EOF'
TEMP_USER=${TEMP_USER}
TEMP_PASS=${TEMP_PASS}
SUPPORT_PORT=${SUPPORT_PORT}
SESSION_START=${SESSION_START}
SESSION_EXPIRES=${SESSION_EXPIRES}
SESSION_MINUTES=${SESSION_MINUTES}
REBOOT_SAFE=${REBOOT_SAFE:-0}
EOF" >/dev/null 2>&1 || return 1
  return 0
}

clear_state() {
  sudo -n rm -f "$STATE_FILE" >/dev/null 2>&1 || true
}

session_active() {
  load_state || return 1
  local now
  now="$($DATE_BIN +%s)"
  [[ "${SESSION_EXPIRES:-0}" -gt "$now" ]] || return 1
  return 0
}

session_expired() {
  load_state || return 0
  local now
  now="$($DATE_BIN +%s)"
  [[ "${SESSION_EXPIRES:-0}" -le "$now" ]]
}

# ----------------------------- User Management --------------------------------
gen_temp_pass() {
  tr -dc 'A-Za-z0-9' </dev/urandom 2>/dev/null | head -c 10
}

support_user_exists() {
  sudo -n "$ID_BIN" "$TEMP_USER" >/dev/null 2>&1
}

delete_support_user() {
  if support_user_exists; then
    sudo -n "$USERDEL_BIN" -r "$TEMP_USER" >/dev/null 2>&1 || sudo -n "$USERDEL_BIN" "$TEMP_USER" >/dev/null 2>&1 || true
    log "Deleted support user '$TEMP_USER'."
  fi
}

create_support_user() {
  TEMP_PASS="$(gen_temp_pass)"
  if [[ -z "$TEMP_PASS" ]]; then
    TEMP_PASS="support123"
  fi

  sudo -n "$USERADD_BIN" -m -s /bin/bash "$TEMP_USER" >/dev/null 2>&1 || return 1
  echo "${TEMP_USER}:${TEMP_PASS}" | sudo -n "$CHPASSWD_BIN" >/dev/null 2>&1 || return 1
  
  sudo -n usermod -aG sudo "$TEMP_USER" >/dev/null 2>&1 || return 1
  
  log "Created support user '$TEMP_USER' with temporary password and sudo access."
  return 0
}

ensure_support_user_for_session() {
  if session_active; then
    TEMP_PASS="${TEMP_PASS:-}"
    if [[ -n "$TEMP_PASS" ]] && support_user_exists; then
      return 0
    fi
  fi

  if support_user_exists; then
    delete_support_user
  fi

  create_support_user || return 1
  return 0
}

# -------------------------- Reboot-Safe Mode ----------------------------------
create_reboot_restore_service() {
  sudo -n bash -c "cat > '$REBOOT_SERVICE' <<'SERVICEEOF'
[Unit]
Description=Simple Arcades Remote Support Restore
After=network.target ssh.service

[Service]
Type=oneshot
ExecStart=/bin/bash -c 'if [ -f ${STATE_FILE} ]; then source ${STATE_FILE}; if [ \"\${REBOOT_SAFE:-0}\" -eq 1 ]; then now=\$(date +%%s); if [ \${SESSION_EXPIRES:-0} -gt \$now ]; then if ! id ${TEMP_USER} >/dev/null 2>&1; then useradd -m -s /bin/bash ${TEMP_USER} && echo \"${TEMP_USER}:\${TEMP_PASS}\" | chpasswd && usermod -aG sudo ${TEMP_USER} && echo \"[\$(date +\"%%Y-%%m-%%d %%H:%%M:%%S\")] Restored support user after reboot.\" >> ${LOG_FILE}; fi; fi; fi; fi'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
SERVICEEOF" >/dev/null 2>&1 || return 1

  sudo -n systemctl daemon-reload >/dev/null 2>&1 || true
  sudo -n systemctl enable sa_remote_restore.service >/dev/null 2>&1 || true
  log "Created reboot-safe restore service."
  return 0
}

remove_reboot_restore_service() {
  sudo -n systemctl disable sa_remote_restore.service >/dev/null 2>&1 || true
  sudo -n systemctl stop sa_remote_restore.service >/dev/null 2>&1 || true
  sudo -n rm -f "$REBOOT_SERVICE" >/dev/null 2>&1 || true
  sudo -n systemctl daemon-reload >/dev/null 2>&1 || true
  log "Removed reboot-safe restore service."
}

enable_reboot_safe_mode() {
  if ! session_active; then
    whiptail --title "Remote Support" --msgbox "No active session to enable reboot mode for." 8 50
    return 0
  fi
  
  REBOOT_SAFE=1
  
  local now extra_time
  now="$($DATE_BIN +%s)"
  extra_time="$((30*60))"
  SESSION_EXPIRES="$((SESSION_EXPIRES + extra_time))"
  
  save_state || {
    whiptail --title "Remote Support" --msgbox "Failed to enable reboot mode.\n\nPlease contact Simple Arcades support." 10 60
    return 1
  }
  
  create_reboot_restore_service || {
    whiptail --title "Remote Support" --msgbox "Failed to create reboot service.\n\nPlease contact Simple Arcades support." 10 60
    return 1
  }
  
  log "Reboot-safe mode enabled. Session extended by 30 minutes."
  
  whiptail --title "Reboot Mode Enabled" --msgbox \
"\"Allow Reconnect After Restart\" has been enabled.\n\n\
This keeps your support session active even if the arcade restarts.\n\n\
Your technician can reconnect using the same password after a restart without you needing to create a new session.\n\n\
Your session has been automatically extended by 30 minutes.\n\n\
The session will still expire after the time limit." \
  18 70
}

disable_reboot_safe_mode() {
  if ! session_active; then
    return 0
  fi
  
  REBOOT_SAFE=0
  save_state
  remove_reboot_restore_service
  log "Reboot-safe mode disabled."
}

# ------------------------------ Port Forwarding -------------------------------
show_port_forwarding_instructions() {
  local internal_ip
  internal_ip="$(fetch_internal_ip)"

  whiptail --title "Port Forwarding Setup" --msgbox \
"To allow your technician to connect, your home router needs to be configured to allow the connection.\n\n\
⚠️ IMPORTANT: This will NOT work with:\n\
 • Mobile hotspots or cellular data connections\n\
 • Some internet providers that use special network setups (CGNAT)\n\
 • Public Wi-Fi (hotels, cafes, libraries, etc.)\n\n\
Steps to set up your router:\n\
 1. Open your router settings in a web browser\n\
    (Usually by typing 192.168.1.1 or 192.168.0.1 in the address bar)\n\
 2. Look for \"Port Forwarding\" or \"NAT\" or \"Virtual Server\" settings\n\
 3. Create a new rule with these settings:\n\
    • External Port: ${SUPPORT_PORT}\n\
    • Internal IP: ${internal_ip}\n\
    • Internal Port: ${SUPPORT_PORT}\n\
    • Protocol: TCP\n\
 4. Save your changes\n\n\
If you have both a modem AND a router, you may need to set this up on both devices.\n\n\
Tip: For best results, connect your arcade directly to your TV while troubleshooting (remove any HDMI splitters or AV receivers temporarily)." \
  28 78
}

# ------------------------------ Session Control -------------------------------
disconnect_now() {
  disable_reboot_safe_mode
  delete_support_user
  clear_state
  log "Support session ended."
}

start_disconnect_timer() {
  local seconds="$1"
  local cmd
  cmd="sleep ${seconds}; sudo -n ${USERDEL_BIN} -r ${TEMP_USER} >/dev/null 2>&1 || sudo -n ${USERDEL_BIN} ${TEMP_USER} >/dev/null 2>&1; sudo -n rm -f '${STATE_FILE}' >/dev/null 2>&1; sudo -n systemctl disable sa_remote_restore.service >/dev/null 2>&1; sudo -n rm -f '${REBOOT_SERVICE}' >/dev/null 2>&1; echo \"[\$(${DATE_BIN} '+%Y-%m-%d %H:%M:%S')] Support session auto-ended (timeout).\" >> '${LOG_FILE}'"
  nohup bash -c "$cmd" >/dev/null 2>&1 &
}

connected_any() {
  sudo -n "$LSOF_BIN" -nP -iTCP -sTCP:ESTABLISHED 2>/dev/null | $GREP_BIN -qi "sshd"
}

# ------------------------------- UI Content -----------------------------------
render_connection_card() {
  local ext_ip int_ip status ssh_listen
  ext_ip="$(fetch_external_ip)"
  int_ip="$(fetch_internal_ip)"
  ssh_listen="NO"
  if sshd_listening_on_port; then ssh_listen="YES"; fi

  local pub_status="UNKNOWN"
  if [[ "$ssh_listen" == "YES" ]]; then
    pub_status="$(check_port_with_loading)"
  fi

  local reboot_status="Disabled"
  if [[ "${REBOOT_SAFE:-0}" -eq 1 ]]; then
    reboot_status="Enabled"
  fi

  cat <<EOF
REMOTE SUPPORT IS ENABLED

Login Information:
  Username: ${TEMP_USER}
  Password: ${TEMP_PASS}

Connection Details:
  Your Public IP: ${ext_ip:-Unknown}
  Your Internal IP: ${int_ip:-Unknown}
  Connection Port: ${SUPPORT_PORT}
  Remote Access Ready: ${ssh_listen}
  Internet Reachability: ${pub_status}
  Survives Restarts: ${reboot_status}

What This Means:
  • Share the username and password above with your technician
  • They will use these to connect to your arcade remotely
  • If "Internet Reachability" shows CLOSED or UNKNOWN, you may need
    to check your router's port forwarding settings

Your arcade is ready for your technician to connect.
EOF
}

help_text() {
  cat <<'EOF'
SIMPLE ARCADES REMOTE SUPPORT - HELP

What does this tool do?
  This tool allows a Simple Arcades technician to connect to your
  arcade over the internet to help troubleshoot issues.

  It creates a temporary login that automatically expires after
  the time you choose (usually 60 minutes).

What do you need?
  • Your arcade must be connected to the internet (Wi-Fi or Ethernet)
  • Your home router must be configured to allow the connection
    (called "port forwarding")
  • A regular home internet connection (see below for what won't work)

Setting up port forwarding:
  This tool CANNOT change your router settings automatically.
  
  You'll need to log into your router and set up port forwarding.
  Select "Port forwarding instructions" from the main menu for
  step-by-step guidance.

What connections will NOT work?
  • Mobile hotspots (phone data, MiFi devices)
  • Cellular/LTE home internet from some providers
  • Public Wi-Fi (hotels, cafes, airports)
  • Some apartment/condo building internet services
  
  These use special network setups (CGNAT) that block incoming
  connections for security reasons.

Common issues:
  • "Port Status shows CLOSED" = Router port forwarding not set up
  • "Cannot detect public IP" = Arcade not connected to internet
  • Multiple routers/modems = May need forwarding on each device

Is this secure?
  Yes! The login password is randomly generated each time and only
  works for the time period you choose. The login is automatically
  deleted when the time expires.

When should you use this?
  Only when a Simple Arcades technician asks you to enable remote
  support. Don't leave it running when you're not actively getting
  help.

Questions?
  Contact Simple Arcades support for help.
EOF
}

show_intro() {
  whiptail --title "Simple Arcades Remote Support" --msgbox \
"Welcome to Simple Arcades Remote Support!\n\n\
This tool lets a Simple Arcades technician connect to your arcade to help fix problems.\n\n\
⚠️ ONLY enable remote support when a technician asks you to.\n\n\
Before you start:\n\
 • Make sure your arcade is connected to the internet\n\
   (Wi-Fi or Ethernet cable)\n\
 • You'll need to set up \"port forwarding\" on your home router\n\
   (We'll show you how in the next steps)\n\n\
Press OK to continue." \
  20 74
}

# ------------------------- New Feature Functions ------------------------------
show_connection_details() {
  if ! session_active; then
    whiptail --title "Remote Support" --msgbox "No active support session.\n\nYou need to start a session first." 10 50
    return 0
  fi
  local card
  card="$(render_connection_card)"
  whiptail --title "Connection Details" --msgbox "$card" 26 78 --scrolltext
}

end_support_session() {
  if ! session_active; then
    whiptail --title "Remote Support" --msgbox "No active support session to end." 8 50
    return 0
  fi
  if whiptail --title "Confirm" --yesno "Are you sure you want to end the support session now?\n\nYour technician will be disconnected." 12 60; then
    disconnect_now
    whiptail --title "Session Ended" --msgbox "Remote support session has been ended.\n\nYour technician can no longer connect." 10 60
  fi
}

show_help() {
  local help
  help="$(help_text)"
  whiptail --title "Help - Remote Support" --msgbox "$help" 30 78 --scrolltext
}

check_technician_status() {
  if ! session_active; then
    whiptail --title "Remote Support" --msgbox "No active support session.\n\nYou need to start a session first." 10 50
    return 0
  fi
  
  local msg="Checking for active connections...\n\n"
  
  local support_sessions
  support_sessions=$(sudo -n "$LSOF_BIN" -u "$TEMP_USER" -nP -iTCP -sTCP:ESTABLISHED 2>/dev/null | $GREP_BIN -c "sshd" || echo "0")
  
  if [[ "$support_sessions" -gt 0 ]]; then
    msg+="✓ Your technician IS connected right now\n\n"
    msg+="Active connections: ${support_sessions}\n\n"
    msg+="Your technician is currently working on your arcade."
  else
    msg+="✗ Your technician is NOT connected yet\n\n"
    msg+="The support session is active and ready, but your technician\nhasn't connected yet.\n\n"
    msg+="This is normal if you just enabled support. They may be\ngetting ready to connect."
  fi
  
  whiptail --title "Connection Status" --msgbox "$msg" 16 70
}

extend_session() {
  if ! session_active; then
    whiptail --title "Remote Support" --msgbox "No active support session to extend.\n\nYou need to start a session first." 10 60
    return 0
  fi
  
  local now left new_minutes new_expires
  now="$($DATE_BIN +%s)"
  left=$(( (SESSION_EXPIRES - now + 59) / 60 ))
  
  local input
  input="$(whiptail --title "Extend Session Time" --inputbox \
"Your current session has about ${left} minutes remaining.\n\n\
How many MORE minutes do you want to add?\n\n\
Recommended: 30 minutes\n\
You can add between 5 and 120 minutes." \
14 70 "30" 3>&1 1>&2 2>&3)" || return 0

  input="${input//[^0-9]/}"
  [[ -z "$input" ]] && return 0

  if (( input < 5 )); then input=5; fi
  if (( input > 120 )); then input=120; fi

  new_minutes="$input"
  new_expires="$((SESSION_EXPIRES + new_minutes*60))"
  
  SESSION_EXPIRES="$new_expires"
  save_state || {
    whiptail --title "Remote Support" --msgbox "Failed to save the updated session time.\n\nPlease contact Simple Arcades support." 10 60
    return 1
  }
  
  start_disconnect_timer "$((new_expires - now))"
  
  log "Session extended by ${new_minutes} minutes."
  
  left=$(( (SESSION_EXPIRES - now + 59) / 60 ))
  whiptail --title "Session Extended" --msgbox "Session extended by ${new_minutes} minutes.\n\nNew time remaining: about ${left} minutes.\n\nYour technician now has more time to work on your arcade." 12 70
}

# ------------------------------- Main Flow ------------------------------------
preflight() {
  local missing=()

  for b in "$CURL_BIN" "$AWK_BIN" "$SED_BIN" "$GREP_BIN" "$MKDIR_BIN" "$DATE_BIN" "$SLEEP_BIN" "$LSOF_BIN" "$ID_BIN" "$HOSTNAME_BIN" "$USERADD_BIN" "$USERDEL_BIN" "$CHPASSWD_BIN" "$TOUCH_BIN" "$CHMOD_BIN"; do
    have_exec "$b" || missing+=("$b")
  done

  have_cmd whiptail || missing+=("whiptail")

  if [[ ${#missing[@]} -gt 0 ]]; then
    whiptail --title "Remote Support" --msgbox \
"Some required system tools are missing:\n\n$(printf '%s\n' "${missing[@]}")\n\nPlease contact Simple Arcades support." \
    18 70
    return 1
  fi

  need_sudo || return 1
  return 0
}

ask_session_minutes() {
  local input
  input="$(whiptail --title "Session Duration" --inputbox \
"How long should remote support stay enabled?\n\n\
This is how much time your technician has to connect and work\non your arcade before the session automatically ends.\n\n\
Recommended: 60 minutes\n\
You can choose between 5 and 240 minutes (4 hours)." \
14 70 "$SESSION_MINUTES_DEFAULT" 3>&1 1>&2 2>&3)" || return 1

  input="${input//[^0-9]/}"
  [[ -z "$input" ]] && return 1

  if (( input < 5 )); then input=5; fi
  if (( input > 240 )); then input=240; fi

  SESSION_MINUTES="$input"
  return 0
}

start_support_session() {
  local now expires
  now="$($DATE_BIN +%s)"
  ask_session_minutes || return 0

  expires="$((now + SESSION_MINUTES*60))"

  ensure_support_user_for_session || {
    whiptail --title "Remote Support" --msgbox "Failed to create the support account.\n\nThis usually means a system error occurred.\n\nPlease contact Simple Arcades support." 12 70
    log "ERROR: Failed to create support user."
    return 1
  }

  TEMP_PASS="${TEMP_PASS:-${TEMP_PASS}}"
  SESSION_START="$now"
  SESSION_EXPIRES="$expires"
  REBOOT_SAFE=0

  save_state || {
    whiptail --title "Remote Support" --msgbox "Failed to save session information.\n\nPlease contact Simple Arcades support." 12 70
    log "ERROR: Failed to save state."
    return 1
  }

  if ! sshd_listening_on_port; then
    whiptail --title "Remote Support" --msgbox \
"The remote connection service is not ready.\n\n\
This usually means SSH is not configured correctly on your arcade.\n\n\
Please contact Simple Arcades support for help." \
    12 70
    log "ERROR: sshd not listening on ${SUPPORT_PORT}."
    return 1
  fi

  show_port_forwarding_instructions

  start_disconnect_timer "$((SESSION_MINUTES*60))"
  log "Support session started. Expires in ${SESSION_MINUTES} minutes."

  local card
  card="$(render_connection_card)"
  whiptail --title "Remote Support Enabled" --msgbox "$card" 26 78 --scrolltext

  live_session_menu
}

live_session_menu() {
  while true; do
    if session_expired; then
      disconnect_now
      whiptail --title "Remote Support" --msgbox "Support session has ended (time expired).\n\nYour technician can no longer connect." 10 60
      return 0
    fi

    local choice
    choice="$(whiptail --title "Remote Support (Active)" --menu \
"Choose an option:" 18 74 6 \
"1" "Show connection details" \
"2" "Refresh internet reachability check" \
"3" "End support session now" \
"4" "Back to main menu" \
3>&1 1>&2 2>&3)" || return 0

    case "$choice" in
      1)
        local card
        card="$(render_connection_card)"
        whiptail --title "Connection Details" --msgbox "$card" 26 78 --scrolltext
        ;;
      2)
        force_refresh_public_status
        whiptail --title "Remote Support" --msgbox "Internet reachability status has been refreshed.\n\nSelect \"Show connection details\" to see the updated status." 10 60
        ;;
      3)
        if whiptail --title "Confirm" --yesno "Are you sure you want to end the support session now?\n\nYour technician will be disconnected." 12 60; then
          disconnect_now
          whiptail --title "Session Ended" --msgbox "Remote support session has been ended.\n\nYour technician can no longer connect." 10 60
          return 0
        fi
        ;;
      4)
        return 0
        ;;
    esac
  done
}

test_connectivity() {
  local msg="Checking your arcade's connection...\n\n"
  
  if sshd_listening_on_port; then
    msg+="✓ Remote connection service is ready: YES\n"
  else
    msg+="✗ Remote connection service is ready: NO\n"
    msg+="\nIf this shows NO, please contact Simple Arcades support.\n"
  fi

  local ext_ip
  ext_ip="$(fetch_external_ip)"
  if [[ -n "$ext_ip" ]]; then
    msg+="\n✓ Your public internet address: ${ext_ip}\n"
  else
    msg+="\n✗ Could not detect your public internet address\n"
    msg+="\nThis usually means your arcade is not connected to the internet.\n"
  fi

  whiptail --title "Connection Test" --msgbox "$msg" 16 70
}

main_menu() {
  local choice
  while true; do
    local status_line="Status: No active session"
    if session_active; then
      local now left
      now="$($DATE_BIN +%s)"
      left=$(( (SESSION_EXPIRES - now + 59) / 60 ))
      if (( left < 0 )); then left=0; fi
      status_line="Status: Active session (about ${left} min remaining)"
    fi

    choice="$(whiptail --title "Simple Arcades Remote Support" --menu \
"${status_line}\n\nSelect an option:" 24 78 11 \
"1" "Port forwarding setup instructions" \
"2" "Test your arcade's connection" \
"3" "Start a new support session" \
"4" "Show connection details (if active)" \
"5" "Check if technician is connected" \
"6" "Extend session time (if active)" \
"7" "Allow reconnect after restart (if active)" \
"8" "End support session (if active)" \
"9" "Help - How this works" \
"10" "Exit" \
3>&1 1>&2 2>&3)" || exit 0

    case "$choice" in
      1)
        show_port_forwarding_instructions
        ;;
      2)
        test_connectivity
        ;;
      3)
        start_support_session
        ;;
      4)
        show_connection_details
        ;;
      5)
        check_technician_status
        ;;
      6)
        extend_session
        ;;
      7)
        enable_reboot_safe_mode
        ;;
      8)
        end_support_session
        ;;
      9)
        show_help
        ;;
      10)
        exit 0
        ;;
      *)
        break
        ;;
    esac
  done
}

main() {
  preflight || exit 1

  if support_user_exists && ! session_active; then
    if ! load_state; then
      delete_support_user
      remove_reboot_restore_service
    else
      if session_expired; then
        delete_support_user
        clear_state
        remove_reboot_restore_service
      fi
    fi
  fi

  show_intro

  main_menu
}

main "$@"