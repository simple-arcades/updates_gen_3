sudo /home/pi/RetroPie/custom_scripts/simplearcades_bluetooth.sh 2>/dev/null
