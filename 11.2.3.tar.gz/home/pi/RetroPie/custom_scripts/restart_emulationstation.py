#!/usr/bin/env python3

import time
import uinput
import subprocess

def main():
    time.sleep(1)

    # Send the F4 key to close EmulationStation
    events = (uinput.KEY_F4,)
    with uinput.Device(events) as device:
        time.sleep(1)
        device.emit_click(uinput.KEY_F4)
        time.sleep(1)

if __name__ == "__main__":
    main()