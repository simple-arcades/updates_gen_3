#!/usr/bin/env bash
# Simple Arcades - Bluetooth auto-connect helper
# Invoked by systemd templated unit: simplearcades-connect-bluetooth@{boot|background}.service

set -u

BASE_DIR="/home/pi/RetroPie/custom_scripts"
LOG_DIR="$BASE_DIR/logs"
LOG_FILE="$LOG_DIR/simplearcades_bluetooth_autoconnect.log"

MODE="${1:-boot}"
mkdir -p "$LOG_DIR" >/dev/null 2>&1 || true

ts() { date "+%Y-%m-%d %H:%M:%S"; }
log() { echo "$(ts) $*" >> "$LOG_FILE"; }

device_info_has() {
  local mac="$1"
  local pat="$2"
  bt-device --info "$mac" 2>/dev/null | grep -q "$pat"
}

list_registered() {
  local line
  while read -r line; do
    if [[ "$line" =~ ^(.+)\ \((.+)\)$ ]]; then
      echo "${BASH_REMATCH[2]}"
      echo "${BASH_REMATCH[1]}"
    fi
  done < <(bt-device --list 2>/dev/null)
}

list_paired() {
  local mac name
  while read -r mac && read -r name; do
    if device_info_has "$mac" "Paired: 1"; then
      echo "$mac"
      echo "$name"
    fi
  done < <(list_registered)
}

connect_all_once() {
  local mac name
  while read -r mac && read -r name; do
    bt-device --connect "$mac" >/dev/null 2>&1 || true
  done < <(list_paired)
}

log "Auto-connect start mode=$MODE"

# Ensure bluetooth service is up
systemctl -q is-active bluetooth.service || systemctl start bluetooth.service >/dev/null 2>&1 || true

case "$MODE" in
  boot)
    connect_all_once
    log "Auto-connect boot completed"
    ;;
  background)
    while true; do
      connect_all_once
      sleep 10
    done
    ;;
  *)
    connect_all_once
    ;;
esac

exit 0
