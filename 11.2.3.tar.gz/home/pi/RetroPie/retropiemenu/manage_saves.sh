#!/bin/bash
# manage_saves_v2.2.sh
# Drop-in replacement for manage_saves.sh
#
# Goals (v2.0):
# - Use the new screenshot location: SAVE_DIR/media/images
# - Delete shared preview video only when a game's LAST savestate is deleted
# - Display user friendly save names (use <name> from savestates gamelist.xml)
# - Keep existing menu wording/flow
# - Keep existing preflight checks + "trust but verify" deletes

# -----------------------------------------------------------------------------
# Safely quote strings for XPath (handles filenames with apostrophes)
# -----------------------------------------------------------------------------
xpath_literal() {
  local s="$1"

  # Fast path: no apostrophes
  if [[ "$s" != *"'"* ]]; then
    printf "'%s'" "$s"
    return 0
  fi

  # Build: concat('part1', "'", 'part2', "'", 'part3')
  local q="\"'\""
  local IFS="'"
  local parts=()

  # Split on apostrophes into parts[]
  read -r -a parts <<< "$s"

  printf "concat("
  local i
  for i in "${!parts[@]}"; do
    if [[ $i -gt 0 ]]; then
      printf ", %s, " "$q"
    fi
    printf "'%s'" "${parts[$i]}"
  done
  printf ")"
}

# -----------------------------------------------------------------------------
# CONFIGURATION & PATHS
# -----------------------------------------------------------------------------
ENABLE_DEBUG="false"
DEBUG_LOG="/home/pi/RetroPie/custom_scripts/logs/manage_saves_debug.log"

SAVE_DIR="/home/pi/RetroPie/roms/savestates"
SCREENSHOT_DIR="${SAVE_DIR}/media/images"
VIDEO_DIR="${SAVE_DIR}/media/videos"
GAMELIST="${SAVE_DIR}/gamelist.xml"
FLAG_FILE="/home/pi/RetroPie/custom_scripts/logs/save_state_flag.txt"
ANY_DELETION=0

# Save file (battery save) cleanup
# When enabled, deleting a game's LAST saved state will also delete its matching .srm save file.
# This helps prevent "leftover" .srm files after using Manage Saves.
DELETE_MATCHING_SRM="true"
# Effective per-run setting; default is false (the script will ask when relevant).
DELETE_MATCHING_SRM_EFFECTIVE="false"
# RetroArch memory saves (.srm) usually live under savestates/savefiles on your builds.
# Some older images used "SaveFiles" (capital letters), so we auto-detect either.
resolve_savefiles_dir() {
  local d
  for d in "$SAVE_DIR/savefiles" "$SAVE_DIR/SaveFiles"; do
    if [ -d "$d" ]; then
      printf "%s" "$d"
      return 0
    fi
  done
  return 1
}

SAVEFILES_DIR=""
if SAVEFILES_DIR="$(resolve_savefiles_dir)"; then
  :
else
  SAVEFILES_DIR=""
fi

# -----------------------------------------------------------------------------
# DEBUG
# -----------------------------------------------------------------------------
debug_init() {
  local log_dir
  log_dir="$(dirname "$DEBUG_LOG")"
  mkdir -p "$log_dir" 2>/dev/null || true

  if [ "$ENABLE_DEBUG" = "true" ]; then
    : > "$DEBUG_LOG" || true
  fi
}

debug() {
  if [ "$ENABLE_DEBUG" = "true" ]; then
    printf "%s DEBUG: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$DEBUG_LOG" 2>/dev/null || true
  fi
}

require_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1
}

update_flag() {
  mkdir -p "$(dirname "$FLAG_FILE")" 2>/dev/null || true
  echo -n "1" > "$FLAG_FILE" 2>/dev/null || true
}

reset_flag() {
  mkdir -p "$(dirname "$FLAG_FILE")" 2>/dev/null || true
  echo -n "0" > "$FLAG_FILE" 2>/dev/null || true
}

# -----------------------------------------------------------------------------
# INTRO SCREEN
# -----------------------------------------------------------------------------
intro_screen() {
  dialog --backtitle "Manage Saves" --title "Welcome" \
    --msgbox "Welcome to the Save Management Tool!\n\nThis tool lets you:\n - Browse and delete save states\n\nUse the menus to navigate and select options.\n\nPress OK to continue." 15 65
}

# -----------------------------------------------------------------------------
# HELPER: Remove literal backslashes from a string
# -----------------------------------------------------------------------------
dialog_unescape() {
  # If filenames never have real backslashes, removing them all is safe.
  echo "$1" | sed 's/\\//g'
}

# -----------------------------------------------------------------------------
# TRUST-BUT-VERIFY delete helper
# -----------------------------------------------------------------------------
safe_rm_verify() {
  local target="$1"
  if [ -e "$target" ]; then
    rm -f "$target" 2>/dev/null || true
    if [ -e "$target" ]; then
      debug "WARNING: Failed to remove: $target"
      return 1
    fi
  fi
  return 0
}

# -----------------------------------------------------------------------------
# Friendly display name lookup
# - Reads <name> from SAVE_DIR/gamelist.xml for this save's ./<base>.entry
# -----------------------------------------------------------------------------
get_display_name_for_base() {
  local base="$1"
  local rel_path="./${base}.entry"

  if [ -f "$GAMELIST" ] && require_cmd xmlstarlet; then
    local xp name
    xp="/gameList/game[path=$(xpath_literal "$rel_path")]/name"
    name="$(xmlstarlet sel -t -v "$xp" -n "$GAMELIST" 2>/dev/null | head -n1 | tr -d '\r')"
    name="$(echo "$name" | sed 's/[[:space:]]\+$//')"
    if [ -n "$name" ]; then
      echo "$name"
      return 0
    fi
  fi

  # Fallback
  echo "$base"
  return 0
}

# -----------------------------------------------------------------------------
# MATCHING .SRM SAVEFILES (battery saves)
# -----------------------------------------------------------------------------
derive_rom_base_from_state_base() {
  local base="$1"
  # Expected naming: "Game Name.state1" or "Game Name.stateauto"
  if [[ "$base" =~ ^(.*)\.state([0-9]+|auto)$ ]]; then
    printf '%s' "${BASH_REMATCH[1]}"
  else
    printf '%s' "$base"
  fi
}

other_savestate_entries_exist_for_rom() {
  # Returns 0 (true) if any other .entry exists for the same ROM base
  local rom_base="$1"
  local skip_base="$2"
  local ef b2 rom2

  shopt -s nullglob
  for ef in "$SAVE_DIR"/*.entry; do
    [ -f "$ef" ] || continue
    b2="$(basename "$ef" .entry)"
    [ "$b2" = "$skip_base" ] && continue
    rom2="$(derive_rom_base_from_state_base "$b2")"
    if [ "$rom2" = "$rom_base" ]; then
      shopt -u nullglob
      return 0
    fi
  done
  shopt -u nullglob
  return 1
}

delete_matching_srm_if_applicable() {
  local base="$1"

  [ "$DELETE_MATCHING_SRM_EFFECTIVE" = "true" ] || return 0

  local rom_base dir srm
  rom_base="$(derive_rom_base_from_state_base "$base")"

  # Resolve the SaveFiles folder (supports both "savefiles" and "SaveFiles").
  dir="$SAVEFILES_DIR"
  if [ -z "$dir" ] || [ ! -d "$dir" ]; then
    if dir="$(resolve_savefiles_dir 2>/dev/null)"; then
      :
    else
      return 0
    fi
  fi

  # Only delete the .srm when this was the last saved state entry for that game.
  if other_savestate_entries_exist_for_rom "$rom_base" "$base"; then
    debug "Not deleting .srm for '${rom_base}' (other saved state(s) still exist)"
    return 0
  fi

  # Delete both lower/upper-case variants if present.
  for srm in "$dir/${rom_base}.srm" "$dir/${rom_base}.SRM"; do
    safe_rm_verify "$srm" || true
  done
}

# -----------------------------------------------------------------------------
# VIDEO deletion safety
# - A preview video can be shared across multiple savestate slots for the same ROM.
# - Only delete a referenced video when:
#     (1) this was the last savestate for the ROM, AND
#     (2) no other <game> entries reference the same video path.
# -----------------------------------------------------------------------------
video_referenced_elsewhere() {
  local video_rel="$1"
  local rel_path="$2"  # ./<base>.entry

  if [ -z "$video_rel" ]; then
    return 1
  fi

  if [ -f "$GAMELIST" ] && require_cmd xmlstarlet; then
    local xp c
    xp="/gameList/game[video=$(xpath_literal "$video_rel") and not(path=$(xpath_literal "$rel_path"))]"
    c="$(xmlstarlet sel -t -v "count($xp)" -n "$GAMELIST" 2>/dev/null | tr -d '\r')"
    if [ -n "$c" ] && [ "$c" != "0" ]; then
      return 0
    fi
  fi
  return 1
}

delete_video_if_applicable() {
  local base="$1"
  local video_rel="$2"
  local rel_path="$3"  # ./<base>.entry

  [ -n "$video_rel" ] || return 0

  local rom_base
  rom_base="$(derive_rom_base_from_state_base "$base")"

  # Only delete video when this was the last saved state for that ROM.
  if other_savestate_entries_exist_for_rom "$rom_base" "$base"; then
    debug "Not deleting video for '${rom_base}' (other saved state(s) still exist)"
    return 0
  fi

  # Extra safety: if any other gamelist entries reference this same video, do not delete it.
  if video_referenced_elsewhere "$video_rel" "$rel_path"; then
    debug "Not deleting video '${video_rel}' (referenced by other saved game(s))"
    return 0
  fi

  local abs
  abs="${SAVE_DIR}/${video_rel#./}"
  safe_rm_verify "$abs" || true
}

# -----------------------------------------------------------------------------
# DELETE A SINGLE SAVE
# (by base name)
# -----------------------------------------------------------------------------
delete_save() {
  local raw_base="$1"
  debug "delete_save() called for base: $raw_base"

  local base
  base="$(dialog_unescape "$raw_base")"
  debug "Unescaped base: $base"

  local rel_path
  rel_path="./${base}.entry"

  # Capture referenced video path BEFORE removing this <game> entry from gamelist.
  local video_rel=""
  if [ -f "$GAMELIST" ] && require_cmd xmlstarlet; then
    local XP
    XP="/gameList/game[path=$(xpath_literal "$rel_path")]"
    video_rel="$(xmlstarlet sel -t -v "$XP/video" -n "$GAMELIST" 2>/dev/null | head -n1 | tr -d '\r')"
  fi

  # Remove <game> from gamelist.xml if present
  if [ -f "$GAMELIST" ] && require_cmd xmlstarlet; then
    local XP
    XP="/gameList/game[path=$(xpath_literal "$rel_path")]"

    # If it exists, delete it
    if xmlstarlet sel -t -v "count($XP)" "$GAMELIST" 2>/dev/null | grep -qv '^0$'; then
      xmlstarlet ed --inplace -d "$XP" "$GAMELIST" 2>/dev/null || true
      debug "Removed <game> block for path=$rel_path"
    else
      debug "No matching <game> block for path=$rel_path"
    fi
  else
    if [ -f "$GAMELIST" ] && ! require_cmd xmlstarlet; then
      debug "xmlstarlet not found; skipping gamelist edits."
    fi
  fi

  # Remove files
  safe_rm_verify "$SAVE_DIR/$base"                 # the .state file
  safe_rm_verify "$SAVE_DIR/$base.entry"           # .entry
  safe_rm_verify "$SAVE_DIR/$base.metadata"        # .metadata

  # Screenshot (new location)
  safe_rm_verify "$SCREENSHOT_DIR/$base.png"

  # Best-effort: also remove any leftover PNG beside the savestate (if it exists)
  safe_rm_verify "$SAVE_DIR/$base.png"

  # Optional: remove matching .srm battery save when last state is deleted
  delete_matching_srm_if_applicable "$base" || true

  # Optional: remove shared preview video when last state is deleted
  delete_video_if_applicable "$base" "$video_rel" "$rel_path" || true

  debug "All files removed for: $base"
}

# -----------------------------------------------------------------------------
# BROWSE SAVES MENU
# -----------------------------------------------------------------------------
browse_saves() {
  local saves=()
  local base display unique_display
  local -A display_counts
  local -A label_to_base
  local label

  for entry_file in "$SAVE_DIR"/*.entry; do
    [ -f "$entry_file" ] || continue
    base="$(basename "$entry_file" .entry)"

    display="$(get_display_name_for_base "$base")"

    # If two entries happen to share the exact same display name, make it unique.
    display_counts["$display"]=$(( ${display_counts["$display"]:-0} + 1 ))
    if [ "${display_counts["$display"]}" -gt 1 ]; then
      unique_display="${display} (${display_counts["$display"]})"
    else
      unique_display="$display"
    fi

    # Show ONLY the user-friendly label in the checklist.
    # Tag = label (returned by dialog), Item = empty.
    label="$unique_display"
    saves+=("$label" "" "off")
    label_to_base["$label"]="$base"
  done

  if [ ${#saves[@]} -eq 0 ]; then
    dialog --msgbox "No saves found." 8 30
    return
  fi

  local selected ec
  selected=$(dialog --checklist     "Select saves to delete (permanently):

Back Button = check highlighted selection.
Select Button = save and confirm choice."     20 70 10     "${saves[@]}"     2>&1 >/dev/tty)
  ec=$?

  debug "dialog exit code: $ec"
  debug "selected raw: '$selected'"

  if [ $ec -eq 0 ] && [ -n "$selected" ]; then
    mapfile -t selections < <(echo "$selected" | awk -F'"' '{for(i=2;i<=NF;i+=2) if(length($i)) print $i}')

    if [ ${#selections[@]} -gt 0 ]; then
      
# Build bases to delete for downstream logic (SRM/video safety decisions).
declare -A selected_base
bases_to_delete=()
for label in "${selections[@]}"; do
  label_clean="$(dialog_unescape "$label")"
  base="${label_to_base["$label_clean"]}"
  # Fallback: try raw label key if needed
  if [ -z "$base" ]; then
    base="${label_to_base["$label"]}"
  fi
  [ -n "$base" ] || continue
  bases_to_delete+=("$base")
  selected_base["$base"]=1
done

local confirm_msg="Are you sure you want to permanently delete the selected saves?"
dialog --yesno "$confirm_msg" 12 70
      if [ $? -eq 0 ]; then

# Optional: offer to remove in-game save data (SRM) ONLY when relevant.
# SRM is the game's normal in-game save (battery save), not a save-state slot.
# We only offer this when the selected deletions will remove the last remaining
# save-state(s) for a game. Default is NO (no surprises).
DELETE_MATCHING_SRM_EFFECTIVE="false"
if [ "$DELETE_MATCHING_SRM" = "true" ] && [ ${#bases_to_delete[@]} -gt 0 ]; then
  declare -A rom_check_done
  needs_srm_prompt=0

  for base in "${bases_to_delete[@]}"; do
    rom_base="$(derive_rom_base_from_state_base "$base")"
    [ -n "$rom_base" ] || continue
    [ -n "${rom_check_done["$rom_base"]}" ] && continue
    rom_check_done["$rom_base"]=1

    # Determine whether any OTHER savestate entry for this ROM will remain
    remaining=0
    shopt -s nullglob
    for ef in "$SAVE_DIR"/*.entry; do
      [ -f "$ef" ] || continue
      b2="$(basename "$ef" .entry)"
      rom2="$(derive_rom_base_from_state_base "$b2")"
      [ "$rom2" = "$rom_base" ] || continue

      # If this base is NOT selected for deletion, it will remain
      if [ -z "${selected_base["$b2"]}" ]; then
        remaining=1
        break
      fi
    done
    shopt -u nullglob

    if [ "$remaining" -eq 0 ]; then
      needs_srm_prompt=1
      break
    fi
  done

  if [ "$needs_srm_prompt" -eq 1 ]; then
    dialog --defaultno --yesno "Also remove the game's in-game save data (SRAM)?\n\nThis is the normal save made from the game's own menus (not a save-state slot).\n\nIf you say Yes, in-game progress for any game where you are deleting the LAST saved state will be reset." 14 70
    if [ $? -eq 0 ]; then
      DELETE_MATCHING_SRM_EFFECTIVE="true"
    fi
  fi
fi
        local total=${#selections[@]}
        local i=0
        (
          for label in "${selections[@]}"; do
            label_clean="$(dialog_unescape "$label")"
            base="${label_to_base["$label_clean"]}"
            if [ -z "$base" ]; then
              base="${label_to_base["$label"]}"
            fi
            if [ -z "$base" ]; then
              debug "WARNING: Could not map selection label to base filename: raw='$label' clean='$label_clean'"
              continue
            fi

            i=$((i + 1))
            local percent=$((100 * i / total))
            echo "$percent"
            echo "XXX"
            echo "Deleting: $label_clean"
            echo "XXX"
            delete_save "$base"
          done
        ) | dialog --gauge "Deleting saves, please wait..." 10 70 0

        dialog --msgbox "Deletion complete." 8 30
        update_flag
        ANY_DELETION=1
        touch /tmp/es-restart 2>/dev/null || true
      fi
    fi
  fi
}


# -----------------------------------------------------------------------------
# Restart emulationstation after deletion of game is made
# -----------------------------------------------------------------------------
restart_es_after_deletion() {
  debug "restart_es_after_deletion(): No watcher/process kills needed, since we launched from retropiemenu."

  # Orphan cleanup: remove <game> entries pointing to missing .entry files
  debug "Performing orphan cleanup..."
  if [[ -f "$GAMELIST" ]] && require_cmd xmlstarlet; then
    while IFS= read -r path; do
      [[ -z "$path" ]] && continue
      local local_file
      local_file="${SAVE_DIR}/${path##*/}"
      if [[ ! -f "$local_file" ]]; then
        debug "Removing orphaned entry for path: $path"
        local XP
        XP="/gameList/game[path=$(xpath_literal "$path")]"
        xmlstarlet ed --inplace -d "$XP" "$GAMELIST" 2>/dev/null || true
      fi
    done < <(xmlstarlet sel -t -m "/gameList/game/path" -v "." -n "$GAMELIST" 2>/dev/null)
  else
    debug "No $GAMELIST found or xmlstarlet missing; skipping orphan cleanup."
  fi

  debug "Running check_recycle_bin.sh in background..."
  if [ -x /home/pi/RetroPie/custom_scripts/check_recycle_bin.sh ]; then
    nohup /home/pi/RetroPie/custom_scripts/check_recycle_bin.sh >/dev/null 2>&1 &
  else
    debug "check_recycle_bin.sh not found or not executable; skipping."
  fi

  # Optional video (ignore failures)
  if require_cmd omxplayer && [ -f "/opt/retropie/configs/all/emulationstation/scripts/videos/exit_deleted_games.mp4" ]; then
    omxplayer -b "/opt/retropie/configs/all/emulationstation/scripts/videos/exit_deleted_games.mp4" >/dev/null 2>&1 &
  fi

  debug "Restarting EmulationStation..."
  if require_cmd python3 && [ -f /home/pi/RetroPie/custom_scripts/restart_emulationstation.py ]; then
    python3 /home/pi/RetroPie/custom_scripts/restart_emulationstation.py >/dev/null 2>&1 &
  else
    debug "restart_emulationstation.py not found; cannot restart ES automatically."
  fi

  debug "Resetting flag file to 0"
  reset_flag

  debug "Done triggering ES restart. Exiting Manage Saves script now."
  exit 0
}

# -----------------------------------------------------------------------------
# MAIN MENU
# -----------------------------------------------------------------------------
main_menu() {
  while true; do
    local choice
    choice=$(dialog --menu "Save Management" 15 50 5 \
      1 "Browse Saves & Delete" \
      2 "Exit" \
      2>&1 >/dev/tty)

    case "$choice" in
      1) browse_saves ;;
      2)
        if [ "$ANY_DELETION" -eq 1 ]; then
          restart_es_after_deletion
        else
          break
        fi
        ;;
      *)
        if [ "$ANY_DELETION" -eq 1 ]; then
          restart_es_after_deletion
        else
          break
        fi
        ;;
    esac
  done
}

# -----------------------------------------------------------------------------
# SCRIPT START
# -----------------------------------------------------------------------------
debug_init

if ! require_cmd dialog; then
  echo "[manage_saves] ERROR: 'dialog' is required." >&2
  exit 1
fi

if [ ! -d "$SAVE_DIR" ]; then
  dialog --msgbox "Save folder not found.\n\nExpected: $SAVE_DIR" 10 55
  clear
  exit 0
fi

intro_screen
main_menu
clear
