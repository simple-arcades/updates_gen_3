#!/bin/bash


# Read the selected music folder from the flag file
MUSIC_FOLDER=$(cat /home/pi/music_settings/selected_playlist.flag)

# Start background music from the selected folder
mpg123 -Z "$MUSIC_FOLDER"/*.mp3 > /dev/null 2>&1 &

# Check if "music off at bootup" is selected
if [ "$(cat /home/pi/music_settings/onoff.flag)" == "0" ]; then
    pkill -STOP mpg123
fi

emulationstation --no-splash