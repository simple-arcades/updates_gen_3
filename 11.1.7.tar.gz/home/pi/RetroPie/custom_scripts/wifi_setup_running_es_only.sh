#!/usr/bin/env bash
#
# Simple Arcades – Network Setup Tool  (Pi 3B/3B+/4 & newer)
# Works with 2.4 GHz and 5 GHz networks, filters hidden SSIDs,
# never quits unless you choose Quit.

###############################################################################
# CONFIG
###############################################################################
BACKTITLE="Simple Arcades Network Setup"
TITLE="Simple Arcades Network Setup"
INTERFACE="wlan0"
SCAN_TIMEOUT=15               # max seconds to wait for a *fresh* scan
MIN_PSK=2
COUNTRY="US"                  # change for non-US units
OSK_PATH="/opt/retropie/admin/joy2key/osk.py"
WPA_CONF="/etc/wpa_supplicant/wpa_supplicant.conf"
LOCKFILE="/var/run/simplearcades_wifi_setup.lock"

###############################################################################
# ONE-INSTANCE GUARD
###############################################################################
if ! exec 200>"$LOCKFILE"; then echo "Lockfile error"; exit 1; fi
flock -n 200 || { echo "Another copy is running."; exit 1; }
echo $$ 1>&200   # record PID

###############################################################################
# ROLLBACK SAFETY
###############################################################################
ROLLBACK=1
backup_wpa()  { cp "$WPA_CONF" "/tmp/wpa.bak.$$" 2>/dev/null; }
restore_wpa() { [[ -f /tmp/wpa.bak.$$ ]] && cp "/tmp/wpa.bak.$$" "$WPA_CONF"
                wpa_cli -i "$INTERFACE" reconfigure &>/dev/null; }
trap '((ROLLBACK)) && restore_wpa; clear' EXIT

###############################################################################
# REG-DOMAIN  (needed for 5 GHz visibility)
###############################################################################
set_reg_domain() {
  local cur
  cur=$(iw reg get | awk '/country/{print $2; exit}' | cut -d: -f1)
  [[ "$cur" != "$COUNTRY" ]] && iw reg set "$COUNTRY" &>/dev/null
}

###############################################################################
# SSID ESCAPE  (handles spaces, quotes, Unicode)
###############################################################################
escape_ssid() {
  local s="$1"
  if LC_ALL=C printf '%s' "$s" | grep -q '^[ -~]*$' \
     && [[ "$s" != *\"* && "$s" != *\\* ]]; then
       printf '"%s"' "$s"
  else
       printf '0x%s' "$(printf '%s' "$s" | xxd -p -c256)"
  fi
}

###############################################################################
# CLEAR CONFIG
###############################################################################
clear_wifi_config() {
  dialog --backtitle "$BACKTITLE" --title "$TITLE" \
    --yesno "Erase ALL saved Wi-Fi networks and start fresh?" 8 60 || return
  cp "$WPA_CONF" "${WPA_CONF}.bak.$(date +%s)" 2>/dev/null
  cat > "$WPA_CONF" <<EOF
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1
country=$COUNTRY
EOF
  chmod 600 "$WPA_CONF"
  set_reg_domain
  wpa_cli -i "$INTERFACE" reconfigure &>/dev/null
  dialog --backtitle "$BACKTITLE" --title "$TITLE" \
    --msgbox "Saved networks wiped. Scan to connect again." 7 60
}

###############################################################################
# INPUT BOX  (dialog or on-screen keyboard)
###############################################################################
inputBox() {
  local prompt="$1" def="$2" min="${3:-0}" txt ret
  if [[ -f $OSK_PATH ]]; then
    txt=$(python3 "$OSK_PATH" --backtitle "$BACKTITLE" --inputbox "$prompt" \
          --minchars "$min" "$def" 2>&1 >/dev/tty); ret=$?
    ((ret)) && return $ret; printf '%s\n' "$txt"; return 0
  fi
  while true; do
    txt=$(dialog --backtitle "$BACKTITLE" --title "$TITLE" \
          --inputbox "$prompt" 10 70 "$def" 2>&1 >/dev/tty); ret=$?
    ((ret)) && return $ret
    if (( ${#txt} >= min )); then printf '%s\n' "$txt"; return 0; fi
    dialog --backtitle "$BACKTITLE" --title "$TITLE" \
           --msgbox "Need at least $min characters." 6 50
  done
}

###############################################################################
# SPINNER
###############################################################################
spin() {  # $1 message  $2 seconds
  local i chars=( '/' '-' '\' '|' )
  for ((i=0;i<$2;i++)); do
    dialog --backtitle "$BACKTITLE" --title "$TITLE" \
      --infobox "\n$1\n\n${chars[i%4]}  Please wait…" 8 60
    sleep 1
  done
}

###############################################################################
# SCAN & NETWORK LIST  (filters hidden SSIDs)
###############################################################################
scan_wifi() {
  dialog --backtitle "$BACKTITLE" --title "$TITLE" \
    --infobox "\nScanning for Wi-Fi networks …\n" 6 50
  local before after i
  before=$(wpa_cli -i "$INTERFACE" scan_results | awk 'NR==2{print $1}')
  wpa_cli -i "$INTERFACE" scan &>/dev/null
  for ((i=0;i<$SCAN_TIMEOUT;i++)); do
    sleep 1
    after=$(wpa_cli -i "$INTERFACE" scan_results | awk 'NR==2{print $1}')
    [[ $after != "$before" ]] && break
  done
}

get_network_list() {
  wpa_cli -i "$INTERFACE" scan_results | awk '
    NR==1 || $1 == "bssid" { next }          # skip headers
    {
      ssid = "";
      for (i = 5; i <= NF; i++) {
        ssid = ssid (i == 5 ? "" : " ") $i;  # rebuild SSID
      }
      if (ssid != "" && ssid !~ /^\\x00/)    # ignore hidden
          print ssid;
    }'
}

###############################################################################
# PROFILE UTILITIES
###############################################################################
delete_profiles_matching() {  # $1 SSID
  local ssid="$1"
  wpa_cli -i "$INTERFACE" list_networks | tail -n +2 |
  while read -r id cur rest; do
     [[ $cur == "$ssid" ]] && wpa_cli -i "$INTERFACE" remove_network "$id" &>/dev/null
  done
}

###############################################################################
# CONNECT / DISCONNECT
###############################################################################
connect_wifi() {  # $1 SSID  $2 PSK  [$3 hidden]
  local ssid="$1" psk="$2" hidden="$3"

  spin "Connecting to \"$ssid\" …" 2
  delete_profiles_matching "$ssid"

  # 1) create profile
  local id
  id=$(wpa_cli -i "$INTERFACE" add_network | grep -Eo '^[0-9]+') || {
      dialog --msgbox "Could not add a new network." 6 50; return 1; }

  # 2) SSID
  if ! wpa_cli -i "$INTERFACE" set_network "$id" ssid "\"$ssid\"" &>/dev/null; then
      dialog --msgbox "Failed to write SSID to wpa_supplicant." 6 55; return 1
  fi

  # 3) Hidden flag (if requested)
  [[ $hidden == hidden ]] && \
      wpa_cli -i "$INTERFACE" set_network "$id" scan_ssid 1 &>/dev/null

  # 4) PSK or open
  if [[ -n $psk ]]; then
      if ! wpa_cli -i "$INTERFACE" set_network "$id" psk "\"$psk\"" &>/dev/null; then
          dialog --msgbox "Failed to set the password." 6 45; return 1
      fi
  else
      wpa_cli -i "$INTERFACE" set_network "$id" key_mgmt NONE &>/dev/null
  fi

  # 5) enable + select + apply
  wpa_cli -i "$INTERFACE" enable_network  "$id" &>/dev/null
  wpa_cli -i "$INTERFACE" select_network  "$id" &>/dev/null
  wpa_cli -i "$INTERFACE" save_config reconfigure &>/dev/null

  # 6) adaptive wait (up to 180 s for DFS)
  local connected=0 state
  for ((t=0; t<180; t++)); do
      state=$(wpa_cli -i "$INTERFACE" status | awk -F= '/^wpa_state=/{print $2}')
      [[ $state == "COMPLETED" ]] && { connected=1; break; }

      # refresh scan every 15 s to keep the AP visible
      (( t % 15 == 0 )) && wpa_cli -i "$INTERFACE" scan &>/dev/null
      spin "Waiting for the access point …" 1
  done

  # 7) result
  if (( connected )); then
      # ── NEW: wait (max 5 s) until wlan0 actually has an IPv4 address ──
      for ((i=0;i<5;i++)); do
         ip -4 addr show "$INTERFACE" | grep -q 'inet ' && break
          spin "Waiting for IP assignment …" 1
      done

      dialog --backtitle "$BACKTITLE" --title "$TITLE" \
             --msgbox "Success! You’re connected to \"$ssid\"." 6 50
      ROLLBACK=0
      return 0
  fi

}

disconnect_wifi() {
  wpa_cli -i "$INTERFACE" disconnect &>/dev/null
  dialog --backtitle "$BACKTITLE" --title "$TITLE" \
    --msgbox "Wi-Fi has been disconnected." 6 50
}

###############################################################################
# MAIN MENU
###############################################################################
main_menu() {
  mapfile -t nets < <(get_network_list)
  
  local st ip wip ess eip header idx choice
  st=$(wpa_cli -i "$INTERFACE" status)

  # Pull addresses straight from the kernel
  wip=$(ip -4 addr show "$INTERFACE" | awk '/inet /{print $2}' | cut -d/ -f1)
  eip=$(ip -4 addr show eth0         | awk '/inet /{print $2}' | cut -d/ -f1)

  ess=$(awk -F= '/^ssid=/{print $2}' <<<"$st")


  header="Current status:\n"
  [[ $eip ]] && header+="Ethernet IP : $eip\n"
  [[ $wip ]] && header+="Wi-Fi IP    : $wip\n"
  [[ $ess ]] && header+="Connected to: $ess\n"
  [[ -z $eip$wip ]] && header+="(no network connection)\n"

  local items=(); idx=1
  for s in "${nets[@]}"; do items+=("$idx" "$s"); ((idx++)); done
  items+=("S" "Scan again")
  items+=("H" "Hidden network (manual)")
  items+=("D" "Disconnect Wi-Fi")
  items+=("C" "Clear saved Wi-Fi list")
  items+=("Q" "Quit")

  choice=$(dialog --backtitle "$BACKTITLE" --title "$TITLE" \
    --menu "$header\nSelect an option:" 25 70 15 "${items[@]}" 2>&1 >/dev/tty) || return 2

  case "$choice" in
    S) scan_wifi; return 2 ;;
    D) disconnect_wifi; return 2 ;;
    C) clear_wifi_config; scan_wifi; return 2 ;;
    H)
       local hid=$(inputBox "Hidden network name (SSID):" "" 1) || return 1
       local pw=$(inputBox "Password (blank = open):" "" $MIN_PSK)   || return 1
       [[ -z $pw ]] && dialog --yesno "Connect without a password?" 6 45 || true
       connect_wifi "$hid" "$pw" hidden; return 2 ;;
    Q) return 0 ;;
    *) local idx=$((choice-1))
	   local ssid="${nets[$idx]}"
       local pw=$(inputBox "Password for \"$ssid\" (blank = open):" "" $MIN_PSK) || return 1
       [[ -z $pw ]] && dialog --yesno "Connect without a password?" 6 45 || true
       connect_wifi "$ssid" "$pw"; return 2 ;;
  esac
}

###############################################################################
# INTRO & RUN
###############################################################################
dialog --backtitle "$BACKTITLE" --title "$TITLE" --msgbox \
"Welcome to Simple Arcades Network Setup!

• Shows Ethernet & Wi-Fi IPs  
• Scans 2.4 GHz ***and*** 5 GHz networks  
• Lets you connect, disconnect, or wipe saved Wi-Fi

Press OK to continue." 11 60

(( EUID == 0 )) || { echo "Run with sudo."; exit 1; }

set_reg_domain
backup_wpa
scan_wifi

while true; do
  main_menu
  [[ $? -eq 0 ]] && break      # Quit selected
done
clear
