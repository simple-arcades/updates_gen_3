# Run the Python script

python3 /home/pi/RetroPie/roms/tools/control_tester.py > /dev/null 2>&1
stty sane
 