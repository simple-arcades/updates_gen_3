#!/bin/bash

# shutdown.sh
# Created/updated: 2025-12-26
#
# Purpose:
# Play the shutdown video during shutdown. This script is intentionally designed
# to NEVER block shutdown.
#
# Important:
# This script must NOT be called from ExecStartPre= in systemd-poweroff.service.
# Doing so caused a consistent late-shutdown hang (video completes, but system
# never reaches full poweroff; ping replies, SSH dead, no GPIO wake; requires
# unplug/replug).
#
# Correct integration:
# Called by /etc/systemd/system/shutdown-video.service (Type=oneshot), which runs
# BEFORE systemd-poweroff/reboot/halt services via target ordering.
#
# Safety measures:
# - Hard timeout around omxplayer so it cannot stall shutdown
# - pkill cleanup of omxplayer processes to avoid stragglers
# - Always exits 0 so shutdown continues even if playback fails

set -u

LOG="/var/log/shutdown_video.log"
VIDEO="/opt/retropie/configs/all/emulationstation/scripts/videos/shutdown.mp4"
PLAYER="/usr/bin/omxplayer"

ts() { date --iso-8601=seconds; }

{
  echo "----- $(ts) shutdown video start -----"
  echo "Player: $PLAYER"
  echo "Video:  $VIDEO"
} >> "$LOG"

# Hard timeout so shutdown can never hang here.
# If omxplayer misbehaves or forks weirdly, we still proceed.
if [ -x /usr/bin/timeout ]; then
  /usr/bin/timeout -k 2 12 "$PLAYER" -b --no-osd --no-keys "$VIDEO" >/dev/null 2>&1 || true
else
  "$PLAYER" -b --no-osd --no-keys "$VIDEO" >/dev/null 2>&1 || true
fi

# Clean up any stragglers (covers fork/child edge cases)
pkill -x omxplayer.bin 2>/dev/null || true
pkill -x omxplayer 2>/dev/null || true

echo "----- $(ts) shutdown video end -----" >> "$LOG"
sync
exit 0
