#!/usr/bin/env bash
# Simple Arcades - Bluetooth Connection Tool (v2)
# Customer-facing, dummy-proof dialog UI (ASCII-only).
# Intended to be launched from the RetroPie menu with sudo.

set -u

APP_NAME="Simple Arcades Bluetooth Tool"
VERSION="2.4"
is_mac() {
  local m="$1"
  [[ "$m" =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]
}


BASE_DIR="/home/pi/RetroPie/custom_scripts"
CFG_DIR="$BASE_DIR/config"
LOG_DIR="$BASE_DIR/logs"
HELPER_DIR="$BASE_DIR/bluetooth_helpers"

CFG_FILE="$CFG_DIR/simplearcades_bluetooth.cfg"
LOG_FILE="$LOG_DIR/simplearcades_bluetooth.log"

CONNECT_SCRIPT="$BASE_DIR/simplearcades_bt_connect.sh"
SERVICE_FILE="/etc/systemd/system/simplearcades-connect-bluetooth@.service"
UDEV_RULE="/etc/udev/rules.d/99-simplearcades-bluetooth.rules"

# ---------- basics ----------
ts() { date "+%Y-%m-%d %H:%M:%S"; }

log() {
  mkdir -p "$LOG_DIR" >/dev/null 2>&1 || true
  echo "$(ts) $*" >> "$LOG_FILE"
}

support_code() { date "+%Y%m%d-%H%M%S"; }

die() {
  local code
  code="$(support_code)"
  log "ERROR code=$code msg=$*"
  dialog --backtitle "$APP_NAME" --msgbox "Something went wrong.\n\nPlease contact Simple Arcades support and provide this code:\n\n$code\n\nPress OK to return." 14 70 >/dev/tty
  exit 1
}

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

is_root() { [[ "${EUID:-$(id -u)}" -eq 0 ]]; }

ensure_dirs() {
  mkdir -p "$CFG_DIR" "$LOG_DIR" "$HELPER_DIR" >/dev/null 2>&1 || true
  if [[ ! -f "$CFG_FILE" ]]; then
    cat > "$CFG_FILE" <<'EOF'
# Simple Arcades Bluetooth config
# connect_mode: default | boot | background
connect_mode=boot
EOF
  fi
}

cfg_get() {
  local key="$1"
  local def="${2:-}"
  local val
  val="$(grep -E "^${key}=" "$CFG_FILE" 2>/dev/null | tail -n1 | cut -d= -f2-)"
  [[ -z "${val:-}" ]] && echo "$def" || echo "$val"
}

cfg_set() {
  local key="$1"
  local val="$2"
  if grep -qE "^${key}=" "$CFG_FILE" 2>/dev/null; then
    sed -i "s#^${key}=.*#${key}=${val}#g" "$CFG_FILE"
  else
    echo "${key}=${val}" >> "$CFG_FILE"
  fi
}

ok_msg() {
  dialog --backtitle "$APP_NAME" --msgbox "$1" 14 70 >/dev/tty
}

info_box() {
  dialog --backtitle "$APP_NAME" --infobox "$1" 6 70 >/dev/tty
}

confirm() {
  dialog --backtitle "$APP_NAME" --yesno "$1" 10 70 >/dev/tty
}

welcome() {
  dialog --backtitle "$APP_NAME" --msgbox \
"Welcome to the Simple Arcades Bluetooth Connection Tool (v${VERSION})!

Use this tool to connect a Bluetooth controller for external control.\n\nBefore you begin:\n- Turn the controller ON\n- Put it into pairing mode\n- Keep it near the arcade\n\nPress OK to continue." 18 70 >/dev/tty
}

require_sudo() {
  if ! is_root; then
    dialog --backtitle "$APP_NAME" --msgbox \
"Please launch this tool from the RetroPie menu.\n\nIf you are a technician running this from SSH, re-run with sudo." 12 70 >/dev/tty
    exit 1
  fi
}

bt_service_ensure() {
  if ! systemctl -q is-active bluetooth.service; then
    log "Starting bluetooth.service"
    systemctl start bluetooth.service >/dev/null 2>&1 || true
  fi
}

rfkill_unblock_if_needed() {
  if command -v rfkill >/dev/null 2>&1; then
    if rfkill list bluetooth 2>/dev/null | grep -qi "Soft blocked: yes"; then
      log "rfkill unblock bluetooth"
      rfkill unblock bluetooth >/dev/null 2>&1 || true
    fi
  fi
}

# ---------- device listing ----------
# We never show MAC addresses to customers in the UI.
# Internally we map a numbered selection -> MAC.

list_registered_pairs() {
  # emits: mac \n name pairs (internal)
  local line
  while read -r line; do
    if [[ "$line" =~ ^(.+)\ \((.+)\)$ ]]; then
      echo "${BASH_REMATCH[2]}"
      echo "${BASH_REMATCH[1]}"
    fi
  done < <(bt-device --list 2>/dev/null)
}

device_info_has() {
  local mac="$1"
  local pat="$2"
  bt-device --info "$mac" 2>/dev/null | grep -q "$pat"
}

list_paired_pairs() {
  local mac name
  while read -r mac && read -r name; do
    if device_info_has "$mac" "Paired: 1"; then
      echo "$mac"
      echo "$name"
    fi
  done < <(list_registered_pairs)
}

list_connected_pairs() {
  local mac name
  while read -r mac && read -r name; do
    if device_info_has "$mac" "Connected: 1"; then
      echo "$mac"
      echo "$name"
    fi
  done < <(list_registered_pairs)
}

pairs_to_name_list() {
  # input: mac/name pairs on stdin -> output: "- Name"
  local mac name out=""
  while read -r mac && read -r name; do
    [[ -z "${name:-}" ]] && name="Unknown controller"
    out="${out}\n - ${name}"
  done
  [[ -z "$out" ]] && out="\n - (none)"
  echo -e "$out"
}

select_from_pairs() {
  # usage: select_from_pairs "Title" < <(list_paired_pairs)
  # output: selected_mac (or empty if cancelled)
  local title="$1"
  SELECTED_NAME=""
  declare -A idx2mac=()
  declare -A idx2name=()
  local options=()
  local mac name idx=1

  while read -r mac && read -r name; do
    if ! is_mac "$mac"; then
      continue
    fi
    [[ -z "${name:-}" ]] && name="Unknown controller"
    idx2mac["$idx"]="$mac"
    idx2name["$idx"]="$name"
    options+=("$idx" "$name")
    idx=$((idx+1))
  done

  if [[ ${#options[@]} -eq 0 ]]; then
    echo ""
    return 0
  fi

  local choice
  choice="$(dialog --backtitle "$APP_NAME" --menu "$title" 22 76 16 "${options[@]}" 2>&1 >/dev/tty)"
  [[ -z "$choice" ]] && { echo ""; return 0; }

  SELECTED_NAME="${idx2name[$choice]}"
  echo "${idx2mac[$choice]}"
}

# ---------- discovery / pairing ----------
scan_available_pairs() {
  # Emits mac \n name pairs discovered during this scan.
  declare -A paired=()
  declare -A found=()

  local mac name line

  while read -r mac && read -r name; do
    paired["$mac"]="$name"
  done < <(list_paired_pairs)

  info_box "Searching for controllers...\n\nPut your controller in pairing mode now."

  local out
  out="$(
    {
      echo "default-agent"
      echo "scan on"
      sleep 12
      echo "scan off"
      echo "devices"
      echo "quit"
    } | bluetoothctl 2>/dev/null
  )"

  # Extract any MAC addresses from output lines (works across bluetoothctl variants).
  while IFS= read -r line; do
    if [[ "$line" =~ ([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2} ]]; then
      mac="${BASH_REMATCH[0]}"
      name="${line#*$mac }"
      name="${name//$'\r'/}"
      name="${name//$'\t'/ }"
      name="$(echo "$name" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"

      # Filter noise
      [[ -z "$name" ]] && continue
      if echo "$name" | grep -qi "^Unknown"; then
        continue
      fi

      # Exclude already paired
      [[ -n "${paired[$mac]:-}" ]] && continue

      found["$mac"]="$name"
    fi
  done <<< "$out"

  for mac in "${!found[@]}"; do
    echo "$mac"
    echo "${found[$mac]}"
  done
}

get_helper() {
  local name="$1"
  local p="$HELPER_DIR/$name"
  if [[ -x "$p" ]]; then
    echo "$p"
    return 0
  fi
  command -v "$name" 2>/dev/null || true
}

pair_and_connect() {
  ok_msg "Pair a controller\n\n1) Put your controller into pairing mode.\n2) When the scan starts, wait for your controller to appear.\n\nPress OK to start scanning."

  declare -A idx2mac=()
  declare -A idx2name=()
  local options=()
  local mac name idx=1

  while read -r mac && read -r name; do
    [[ -z "${name:-}" ]] && name="Unknown controller"
    idx2mac["$idx"]="$mac"
    idx2name["$idx"]="$name"
    options+=("$idx" "$name")
    idx=$((idx+1))
  done < <(scan_available_pairs)

  if [[ ${#options[@]} -eq 0 ]]; then
    ok_msg "No controllers were found.\n\nMake sure the controller is ON and in pairing mode, then try again."
    return 0
  fi

  local choice
  choice="$(dialog --backtitle "$APP_NAME" --menu "Select a controller to pair" 22 76 16 "${options[@]}" 2>&1 >/dev/tty)"
  [[ -z "$choice" ]] && return 0

  mac="${idx2mac[$choice]}"
  name="${idx2name[$choice]}"

  if ! is_mac "$mac"; then
    log "Scan returned invalid MAC: mac=$mac name=$name"
    ok_msg "We found your controller, but could not read its Bluetooth address.\n\nPlease try again.\n\nPress OK to return to the menu."
    return 0
  fi

  log "Pair requested name='$name' mac=$mac"

  # PS3 special-case
  if echo "$name" | grep -q "PLAYSTATION(R)3 Controller"; then
    bt-device --disconnect="$mac" >/dev/null 2>&1 || true
    bt-device --set "$mac" Trusted 1 >/dev/null 2>&1 || true
    if device_info_has "$mac" "Trusted: 1"; then
      ok_msg "PS3 controller paired.\n\nYou can now remove the USB cable.\n\nPress OK to return to the menu."
      return 0
    fi
    ok_msg "PS3 pairing did not complete.\n\nTry again and follow the on-screen steps.\n\nPress OK to return to the menu."
    return 0
  fi

  # Security mode selection (keep it simple)
  local mode_choice mode
  # Pairing happens automatically. No extra choices are required.
  local modes
  modes=("NoInputNoOutput" "DisplayYesNo" "KeyboardDisplay")
  local agent
  agent="$(get_helper bluez-simple-agent)"
  [[ -z "$agent" ]] && die "Missing pairing helper"

  local fifo line pin error skip_connect
    # Pairing loop: try a few internal methods automatically
  local mode line pin error skip_connect paired_ok
  error=""
  skip_connect=0
  paired_ok=0

  for mode in "${modes[@]}"; do
    log "Pair attempt mode=$mode for $mac ($name)"

    local fifo
    fifo="$(mktemp -u)"
    mkfifo "$fifo"
    exec 3<>"$fifo"

    # Read agent output line-by-line and respond when needed
    while read -r line; do
      case "$line" in
      RequestPinCode*)
        pin="0000"
        dialog --backtitle "$APP_NAME" --infobox "If your controller asks for a PIN, use: 0000" 6 70 >/dev/tty
        echo "$pin" >&3
        read -n 15 line || true
        ;;
      RequestConfirmation*)
        echo "yes" >&3
        read -n 26 line || true
        skip_connect=1
        break
        ;;
      DisplayPasskey*|DisplayPinCode*)
        if [[ "$line" =~ ,\ (.+)\) ]]; then
          pin="${BASH_REMATCH[1]}"
          dialog --backtitle "$APP_NAME" --infobox "If your controller asks for a code, enter: $pin" 6 70 >/dev/tty
        fi
        ;;
      "Creating device failed"*)
        error="$line"
        ;;
      esac
    done < <(stdbuf -oL "$agent" -c "$mode" hci0 "$mac" <&3)

    exec 3>&-
    rm -f "$fifo"

    # Trust-but-verify: did we pair?
    if device_info_has "$mac" "Paired: 1"; then
      paired_ok=1
      error=""
      break
    fi

    # Some devices connect during confirmation
    if [[ "$skip_connect" -eq 1 ]] && device_info_has "$mac" "Connected: 1"; then
      paired_ok=1
      error=""
      break
    fi
  done

  if [[ "$paired_ok" -ne 1 ]]; then
    # Cleanup any partial entry
    bt-device --remove "$mac" >/dev/null 2>&1 || true
    ok_msg "Pairing did not complete.\n\nMake sure the controller is in pairing mode, then try again.\n\nTip (8BitDo Pro 2): Use X mode."
    bluetoothctl info "$mac" 2>/dev/null | head -n 30 | while read -r _l; do log "btctl: ${_l}"; done
    log "Pair failed for $mac ($name): ${error:-unknown}"
    return 0
  fi


  if [[ "$skip_connect" -eq 1 ]]; then
    if device_info_has "$mac" "Connected: 1"; then
      ok_msg "Controller paired and connected.\n\nPress OK to return to the menu."
      return 0
    fi
    ok_msg "Controller paired.\n\nIf it does not connect automatically, use:\nConnect -> Connect a paired controller\n\nPress OK to return to the menu."
    return 0
  fi

  if [[ -z "$error" ]]; then
    bt-device --set "$mac" Trusted 1 >/dev/null 2>&1 || { timeout 10s bluetoothctl trust "$mac" >/dev/null 2>&1 || true; error="Trust step failed"; }
  fi

  if [[ -z "$error" ]]; then
    bt-device --connect "$mac" >/dev/null 2>&1 || true
    if ! device_info_has "$mac" "Connected: 1"; then
      timeout 10s bluetoothctl connect "$mac" >/dev/null 2>&1 || true
    fi
    if device_info_has "$mac" "Paired: 1" && device_info_has "$mac" "Trusted: 1"; then
      if device_info_has "$mac" "Connected: 1"; then
        ok_msg "Success! Controller paired and connected.\n\nPress OK to return to the menu."
        return 0
      fi
      ok_msg "Controller paired.\n\nIt is not connected yet. Use:\nConnect -> Connect a paired controller\n\nPress OK to return to the menu."
      return 0
    fi
    error="Pairing check failed"
  fi

  log "Pair failed name='$name' mac=$mac err='$error'"
  ok_msg "Pairing did not complete.\n\nTry again, and if needed choose a different pairing mode.\n\nPress OK to return to the menu."
  return 0
}

# ---------- actions ----------
show_status() {
  local svc="Not running"
  systemctl -q is-active bluetooth.service && svc="Running"

  local mode
  mode="$(cfg_get connect_mode boot)"

  local paired_list connected_list
  paired_list="$(list_paired_pairs | pairs_to_name_list)"
  connected_list="$(list_connected_pairs | pairs_to_name_list)"

  dialog --backtitle "$APP_NAME" --msgbox \
"Bluetooth service: $svc\nAuto-connect: $mode\n\nPaired controllers:$paired_list\n\nConnected controllers:$connected_list\n\nPress OK to return to the menu." 22 76 >/dev/tty
}

connect_all_now() {
  info_box "Connecting to paired controllers..."
  local mac name connected=0 attempted=0
  while read -r mac && read -r name; do
    attempted=$((attempted+1))
    bt-device --connect "$mac" >/dev/null 2>&1 || true
    if device_info_has "$mac" "Connected: 1"; then
      connected=$((connected+1))
    fi
  done < <(list_paired_pairs)

  if [[ "$attempted" -eq 0 ]]; then
    ok_msg "No paired controllers found.\n\nUse 'Pair a controller' first.\n\nPress OK to return to the menu."
  else
    ok_msg "Connect attempt finished.\n\nConnected now: $connected\n\nPress OK to return to the menu."
  fi
}

connect_one() {
  local mac
  mac="$(select_from_pairs "Select a paired controller to connect" < <(list_paired_pairs))"
  [[ -z "$mac" ]] && { ok_msg "No selection made.\n\nPress OK to return to the menu."; return 0; }

  bt-device --connect "$mac" >/dev/null 2>&1 || true
  if device_info_has "$mac" "Connected: 1"; then
    ok_msg "Controller connected.\n\nPress OK to return to the menu."
  else
    ok_msg "Connect attempt finished.\n\nIf it did not connect, try again or enable Auto-connect.\n\nPress OK to return to the menu."
  fi
}

disconnect_one() {
  local mac
  mac="$(select_from_pairs "Select a connected controller to disconnect" < <(list_connected_pairs))"
  [[ -z "$mac" ]] && { ok_msg "No selection made.\n\nPress OK to return to the menu."; return 0; }

  bt-device --disconnect "$mac" >/dev/null 2>&1 || true
  if device_info_has "$mac" "Connected: 1"; then
    ok_msg "Disconnect attempt finished.\n\nThe controller may still be reconnecting.\n\nPress OK to return to the menu."
  else
    ok_msg "Controller disconnected.\n\nPress OK to return to the menu."
  fi
}

remove_device() {
  local mac
  mac="$(select_from_pairs "Select a paired controller to remove" < <(list_paired_pairs))"
  [[ -z "$mac" ]] && { ok_msg "No selection made.\n\nPress OK to return to the menu."; return 0; }

  if ! confirm "Remove this controller?\n\nThis will forget it from the arcade."; then
    ok_msg "No changes made.\n\nPress OK to return to the menu."
    return 0
  fi

  local out
  out="$(bt-device --remove "$mac" 2>&1 || true)"
  log "Remove device mac=$mac out=$out"

  if bt-device --info "$mac" >/dev/null 2>&1; then
    ok_msg "Remove attempt finished.\n\nIf it still appears, restart the arcade and try again.\n\nPress OK to return to the menu."
  else
    ok_msg "Controller removed.\n\nPress OK to return to the menu."
  fi
}

install_or_update_service() {
  cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Simple Arcades - Connect Bluetooth Controllers (%i)
After=bluetooth.service
Wants=bluetooth.service

[Service]
Type=simple
ExecStart=nice -n19 $CONNECT_SCRIPT %i
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload >/dev/null 2>&1 || true
  log "Wrote service: $SERVICE_FILE"
}

set_connect_mode() {
  local current
  current="$(cfg_get connect_mode boot)"

  local choice
  choice="$(dialog --backtitle "$APP_NAME" --default-item "$current" --menu "Auto-connect (recommended: On startup)" 22 76 16 \
    default "Off (use manual Connect option)" \
    boot "On startup (connect once)" \
    background "Background (keep trying)" \
    2>&1 >/dev/tty)"
  [[ -z "$choice" ]] && { ok_msg "No changes made.\n\nPress OK to return to the menu."; return 0; }

  cfg_set connect_mode "$choice"
  log "connect_mode set to $choice"

  install_or_update_service

  # Apply with verification (trust-but-verify)
  case "$choice" in
    default)
      systemctl disable --now simplearcades-connect-bluetooth@boot.service >/dev/null 2>&1 || true
      systemctl disable --now simplearcades-connect-bluetooth@background.service >/dev/null 2>&1 || true
      ok_msg "Auto-connect turned OFF.\n\nPress OK to return to the menu."
      ;;
    boot)
      systemctl enable --now simplearcades-connect-bluetooth@boot.service >/dev/null 2>&1 || true
      systemctl disable --now simplearcades-connect-bluetooth@background.service >/dev/null 2>&1 || true
      if systemctl -q is-enabled simplearcades-connect-bluetooth@boot.service; then
        ok_msg "Auto-connect set to ON STARTUP.\n\nPress OK to return to the menu."
      else
        ok_msg "Auto-connect setting saved, but could not enable it.\n\nPlease restart the arcade, or contact support.\n\nPress OK to return to the menu."
      fi
      ;;
    background)
      systemctl enable --now simplearcades-connect-bluetooth@background.service >/dev/null 2>&1 || true
      systemctl disable --now simplearcades-connect-bluetooth@boot.service >/dev/null 2>&1 || true
      if systemctl -q is-enabled simplearcades-connect-bluetooth@background.service; then
        ok_msg "Auto-connect set to BACKGROUND.\n\nPress OK to return to the menu."
      else
        ok_msg "Auto-connect setting saved, but could not enable it.\n\nPlease restart the arcade, or contact support.\n\nPress OK to return to the menu."
      fi
      ;;
  esac
}

create_udev_rule() {
  ok_msg "Compatibility option\n\nThis option applies a compatibility tweak for some controllers.\n\nOnly use this if your controller pairs but does not show up in games.\n\nPress OK to continue."

  local mac
  mac="$(select_from_pairs "Select a paired controller" < <(list_paired_pairs))"
  [[ -z "$mac" ]] && { ok_msg "No selection made.\n\nPress OK to return to the menu."; return 0; }

  # Get the name for the rule
  local name
  name="$(bt-device --info "$mac" 2>/dev/null | awk -F': ' '/Name:/{print $2; exit}')"
  [[ -z "${name:-}" ]] && name="Unknown controller"

  local line
  line="SUBSYSTEM==\"input\", ATTRS{name}==\"$name\", MODE=\"0666\", ENV{ID_INPUT_JOYSTICK}=\"1\""

  touch "$UDEV_RULE" >/dev/null 2>&1 || true

  if grep -Fq "$line" "$UDEV_RULE" 2>/dev/null; then
    ok_msg "Compatibility tweak is already applied.\n\nIf the controller still does not work, restart the arcade.\n\nPress OK to return to the menu."
    return 0
  fi

  echo "$line" >> "$UDEV_RULE"
  log "Added udev rule name='$name' mac=$mac line=$line"

  udevadm control --reload-rules >/dev/null 2>&1 || true
  udevadm trigger >/dev/null 2>&1 || true

  ok_msg "Compatibility tweak applied.\n\nRestart the arcade for best results.\n\nPress OK to return to the menu."
}

restart_bluetooth() {
  info_box "Restarting Bluetooth..."
  systemctl restart bluetooth.service >/dev/null 2>&1 || true
  ok_msg "Bluetooth restarted.\n\nPress OK to return to the menu."
}

help_screen() {
  ok_msg "Help\n\nPairing tips:\n- Put the controller in pairing mode before scanning.\n- Keep the controller close to the arcade.\n- If pairing fails, try pairing again and choose a different pairing mode.\n\nConnection tips:\n- If the controller pairs but will not reconnect, turn on Auto-connect.\n\nNeed help?\n- Contact Simple Arcades support."
}

# ---------- main ----------
main() {
  need_cmd dialog
  need_cmd bt-device
  need_cmd bluetoothctl
  need_cmd systemctl

  require_sudo
  ensure_dirs

  log "----- START -----"

  bt_service_ensure
  rfkill_unblock_if_needed

  welcome

  while true; do
    local mode
    mode="$(cfg_get connect_mode boot)"

    local choice
    choice="$(dialog --backtitle "$APP_NAME" --menu "Simple Arcades Bluetooth" 22 76 16 \
      1 "Pair a controller" \
      2 "Status (paired / connected)" \
      3 "Connect (all paired controllers)" \
      4 "Connect (one paired controller)" \
      5 "Disconnect (one connected controller)" \
      6 "Remove a paired controller" \
      7 "Auto-connect settings (current: $mode)" \
      8 "Compatibility option (only if needed)" \
      9 "Restart Bluetooth" \
      H "Help" \
      X "Exit" \
      2>&1 >/dev/tty)"

    case "$choice" in
      1) pair_and_connect ;;
      2) show_status ;;
      3) connect_all_now ;;
      4) connect_one ;;
      5) disconnect_one ;;
      6) remove_device ;;
      7) set_connect_mode ;;
      8) create_udev_rule ;;
      9) restart_bluetooth ;;
      H) help_screen ;;
      X|"") break ;;
      *) break ;;
    esac
  done

  log "----- END -----"
}

main "$@"
