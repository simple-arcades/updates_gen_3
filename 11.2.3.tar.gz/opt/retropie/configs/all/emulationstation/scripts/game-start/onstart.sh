#!/bin/bash

# For debugging: log the first parameter (the launching script's path)
# echo "System parameter: $1" >> /tmp/onstart_debug.log

# Path to the mute sound flag file
MUTE_FLAG="/home/pi/music_settings/mute_launch_sound.flag"
# Read the mute status (0 = sound on, 1 = muted); defaults to "0" if file is missing
MUTE_STATUS=$(cat "$MUTE_FLAG" 2>/dev/null || echo "0")

# Directory containing the random loading videos (helper videos)
VIDEO_DIR="/opt/retropie/configs/all/emulationstation/scripts/videos/loading_screens"

# File for launch video mode (values: 0 = random, 1 = plain, 2 = system-specific)
LAUNCH_VIDEO_MODE_FILE="/home/pi/music_settings/launch_video_mode.flag"
LAUNCH_VIDEO_MODE=$(cat "$LAUNCH_VIDEO_MODE_FILE" 2>/dev/null || echo "0")

# In all cases, stop the music player
pkill -STOP mpg123

# Check if the launching script is located in either of the two directories
if [[ "$1" == /home/pi/RetroPie/retropiemenu/* || "$1" == /home/pi/RetroPie/custom_scripts/* ]]; then
    # Create a marker file to signal that onend.sh should skip extras.
    touch /tmp/skip_extras
    # Skip playing the video, starting the watcher, and process monitor.
else
    # Determine which video to play based on the launch video mode flag.
    if [ "$LAUNCH_VIDEO_MODE" == "1" ]; then
        # Plain launch video (no helper videos)
        VIDEO_TO_PLAY="/opt/retropie/configs/all/emulationstation/scripts/videos/loading.mp4"
    elif [ "$LAUNCH_VIDEO_MODE" == "2" ]; then
        # System-specific helper video:
        # Extract the system name using dirname and basename.
        SYSTEM_NAME=$(basename "$(dirname "$1")")
        SYSTEM_VIDEO_DIR="/opt/retropie/configs/all/emulationstation/scripts/videos/system_specific_launch_videos/${SYSTEM_NAME}"
        if [ -d "$SYSTEM_VIDEO_DIR" ]; then
            # If the system-specific folder exists, select a random MP4 from it.
            VIDEO_TO_PLAY=$(find "$SYSTEM_VIDEO_DIR" -maxdepth 1 -type f -iname '*.mp4' | shuf -n 1)
        fi
        # If no system-specific video is found, fall back to random helper videos.
        if [ -z "$VIDEO_TO_PLAY" ]; then
            VIDEO_TO_PLAY=$(find "$VIDEO_DIR" -maxdepth 1 -type f -iname '*.mp4' | shuf -n 1)
        fi
        # Final fallback: if still no video, use the plain launch video.
        if [ -z "$VIDEO_TO_PLAY" ]; then
            VIDEO_TO_PLAY="/opt/retropie/configs/all/emulationstation/scripts/videos/loading.mp4"
        fi
    else
        # Random helper video mode (flag = 0)
        VIDEO_TO_PLAY=$(find "$VIDEO_DIR" -maxdepth 1 -type f -iname '*.mp4' | shuf -n 1)
        # Fallback: if no file is found, use the plain launch video.
        if [ -z "$VIDEO_TO_PLAY" ]; then
            VIDEO_TO_PLAY="/opt/retropie/configs/all/emulationstation/scripts/videos/loading.mp4"
        fi
    fi

    # Play the launch video (with muted audio or with sound based on the mute flag)
    if [[ "$MUTE_STATUS" == "1" ]]; then
        # Play video with muted audio
        omxplayer -b --adev local --vol -6000 "$VIDEO_TO_PLAY" > /dev/null
    else
        # Play video with audio
        omxplayer -b --adev local "$VIDEO_TO_PLAY" > /dev/null
    fi
	
	# Prevent duplicates (add these guards right before you start them)
	if ! pgrep -f 'ps axww .*retroarch_process_stable\.txt' >/dev/null 2>&1; then
		nohup bash -c 'while true; do ps axww | grep "[r]etroarch" > /tmp/retroarch_process_stable.txt; sleep 1; done' >/dev/null 2>&1 &
	fi

    # Start the saved state watcher
	if ! pgrep -f '/home/pi/RetroPie/custom_scripts/watcher_script\.sh' >/dev/null 2>&1; then
		nohup /home/pi/RetroPie/custom_scripts/watcher_script.sh >/dev/null 2>&1 &
	fi
fi