#!/bin/bash

###############################################################################
# Watcher Script for RetroArch Save States
# - Detects newly created ".stateX" files in SAVE_DIR
# - Creates corresponding ".stateX.entry" files
# - Takes a screenshot, writes metadata, and updates a gamelist.xml
# - Supports multiple slots (state0, state1, state2, etc.)
# - Supports any ROM extension (not just .zip)
###############################################################################

# Set ENABLE_LOGS="true" to enable logging; set to "false" to disable.
ENABLE_LOGS="false"

# If true, delete RetroArch's savestate thumbnail PNG (created beside .state files)
# after we successfully copy it into SCREENSHOT_DIR.
# Set to "false" if you want RetroArch's own save-state menu thumbnails too.
DELETE_RA_THUMB_AFTER_COPY="true"

SAVE_DIR="/home/pi/RetroPie/roms/savestates"
SCREENSHOT_DIR="${SAVE_DIR}/media/images"
VIDEO_DIR="${SAVE_DIR}/media/videos"
GAMELIST="${SAVE_DIR}/gamelist.xml"
RASPI2PNG="/home/pi/raspi2png/raspi2png"
LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/watcher_debug.log"
DEBOUNCE_TIME=2  # seconds to prevent multiple triggers for same file
FLAG_FILE="/home/pi/RetroPie/custom_scripts/logs/save_state_flag.txt"

declare -A LAST_MODIFIED

mkdir -p "$(dirname "$LOG_FILE")"

# Ensure screenshot dir exists
mkdir -p "$SCREENSHOT_DIR"
mkdir -p "$VIDEO_DIR"

# Logging helper function: writes message to LOG_FILE only if ENABLE_LOGS is "true".
log_msg() {
    if [ "$ENABLE_LOGS" = "true" ]; then
        echo "$(date): $1" >> "$LOG_FILE"
    fi
}

# Wait until a file stops growing (prevents partial copies)
wait_until_stable() {
  local f="$1" last=-1 cur=0
  while :; do
    cur=$(stat -c "%s" "$f" 2>/dev/null || echo 0)
    [[ "$cur" -gt 0 && "$cur" = "$last" ]] && break
    last="$cur"; sleep 0.5
  done
}

# Build a safe XPath string literal for xmlstarlet (handles apostrophes)
xpath_literal() {
  case "$1" in *"'"*) ;; *) printf "'%s'" "$1"; return ;; esac
  local s="$1" out="" part
  while [[ "$s" == *"'"* ]]; do
    part="${s%%\'*}"
    out="${out},'${part}',"'"'"'"
    s="${s#*\'}"
  done
  out="${out},'${s}'"
  printf "concat(%s)" "${out#,}"
}

# Log the start of the script
log_msg "Watcher script started at $(date)"

###############################################################################
# System Mapping
###############################################################################
declare -A SYSTEM_MAP=(
    ["3do"]="Panasonic 3DO"
    ["amiga"]="Amiga"
    ["amstradcpc"]="Amstrad CPC"
    ["arcade"]="Arcade"
    ["atari2600"]="Atari 2600"
    ["atari5200"]="Atari 5200"
    ["atari7800"]="Atari 7800"
    ["atari800"]="Atari 800"
    ["atarilynx"]="Atari Lynx"
    ["atomiswave"]="Sega Atomiswave"
    ["cd32"]="Amiga CD32"
    ["cdimono1"]="Philips CD-i"
    ["channelf"]="Fairchild Channel F"
    ["coleco"]="ColecoVision"
    ["dreamcast"]="Sega Dreamcast"
    ["famicom"]="Nintendo Famicom"
    ["fba"]="Final Burn Alpha"
    ["fds"]="Nintendo Famicom Disk System"
    ["gamegear"]="Sega Game Gear"
    ["gb"]="Nintendo Game Boy"
    ["gba"]="Nintendo Game Boy Advance"
    ["gbc"]="Nintendo Game Boy Color"
    ["genesis"]="Sega Genesis"
    ["intellivision"]="Intellivision"
    ["mame-libretro"]="Arcade"
    ["mastersystem"]="Sega Master System"
    ["megadrive"]="Sega Mega Drive"
    ["msx"]="Microsoft MSX"
    ["naomi"]="Sega Naomi"
    ["n64"]="Nintendo 64"
    ["neogeo"]="Neo Geo"
    ["neogeocd"]="Neo Geo CD"
    ["nes"]="Nintendo Entertainment System"
    ["ngp"]="Neo Geo Pocket"
    ["ngpc"]="Neo Geo Pocket Color"
    ["pce-cd"]="PC Engine CD-ROM2"
    ["pcengine"]="TurboGrafx-16"
    ["pico8"]="PICO-8"
    ["psx"]="Sony PlayStation"
    ["saturn"]="Sega Saturn"
    ["savestates"]="Save States"
    ["sega32x"]="Sega 32X"
    ["segacd"]="Sega CD"
    ["sg-1000"]="Sega SG-1000"
    ["sfc"]="Nintendo Super Famicom"
    ["snes"]="Super Nintendo Entertainment System"
    ["tic80"]="TIC-80"
    ["tools"]="Tools"
    ["vectrex"]="GCE Vectrex"
    ["virtualboy"]="Virtual Boy"
    ["wonderswan"]="Bandai WonderSwan"
    ["wonderswancolor"]="Bandai WonderSwan Color"
    ["zxspectrum"]="ZX Spectrum"
)

###############################################################################
# Helper Functions
###############################################################################

escape_parens() {
    local input="$1"
    local out
    out="${input//(/\\(}"
    out="${out//)/\\)}"
    echo "$out"
}

###############################################################################
# get_extra_metadata (tolerant lookup against the source system gamelist.xml)
# Returns: title|genre|publisher|developer|players|rating|releasedate|genreid|video
###############################################################################
get_extra_metadata() {
    local metadata_file="$1"

    # Read ROM path and system gamelist path from the metadata file
    if [[ ! -f "$metadata_file" ]]; then
        echo "||||||||"
        return 1
    fi

    # Retry a few times in case the writer is still flushing
    local max_retries=5 retry_delay=0.5 rc=0 last_mod=0
    while [[ $rc -lt $max_retries ]]; do
        if [[ -s "$metadata_file" ]]; then
            local new_mod=$(stat -c %Y "$metadata_file" 2>/dev/null || echo 0)
            [[ "$new_mod" == "$last_mod" ]] && break || last_mod="$new_mod"
        fi
        sleep "$retry_delay"; ((rc++))
    done

    local rom_path
    rom_path=$(grep -m1 "^ROM=" "$metadata_file" | cut -d '=' -f2- | tr -d '"' | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    if [[ -z "$rom_path" ]]; then
        echo "||||||||"
        return 1
    fi

    local rom_folder orig_gamelist
    rom_folder=$(dirname "$rom_path" | xargs basename)
    orig_gamelist="/home/pi/RetroPie/roms/${rom_folder}/gamelist.xml"
    if [[ ! -f "$orig_gamelist" ]]; then
        echo "||||||||"
        return 1
    fi

    # Build candidate paths: absolute, ./relative, and bare filename
    local abs reldot bare
    abs="$rom_path"
    bare="$(basename "$rom_path")"
    reldot="./${bare}"

    # Quote for XPath
    local XABS XRELDOT XBARE
    XABS=$(xpath_literal "$abs")
    XRELDOT=$(xpath_literal "$reldot")
    XBARE=$(xpath_literal "$bare")

    # XPath tries all three; return first match
    local xp="//game[path=$XABS or path=$XRELDOT or path=$XBARE][1]"

    local title genre publisher developer players rating releasedate genreid video
    title=$(xmlstarlet sel -t -v "$xp/name" -n "$orig_gamelist" 2>/dev/null | head -n1)
    genre=$(xmlstarlet sel -t -v "$xp/genre" -n "$orig_gamelist" 2>/dev/null)
    publisher=$(xmlstarlet sel -t -v "$xp/publisher" -n "$orig_gamelist" 2>/dev/null)
    developer=$(xmlstarlet sel -t -v "$xp/developer" -n "$orig_gamelist" 2>/dev/null)
    players=$(xmlstarlet sel -t -v "$xp/players" -n "$orig_gamelist" 2>/dev/null)
    rating=$(xmlstarlet sel -t -v "$xp/rating" -n "$orig_gamelist" 2>/dev/null)
    releasedate=$(xmlstarlet sel -t -v "$xp/releasedate" -n "$orig_gamelist" 2>/dev/null | head -n1)
    genreid=$(xmlstarlet sel -t -v "$xp/genreid" -n "$orig_gamelist" 2>/dev/null | head -n1)
    video=$(xmlstarlet sel -t -v "$xp/video" -n "$orig_gamelist" 2>/dev/null | head -n1)

    # Defaults
    [[ -z "$title" ]] && title="${bare%.*}"
    [[ -z "$players"   ]] && players="1"
    [[ -z "$genre"     ]] && genre="Unknown"
    [[ -z "$publisher" ]] && publisher="Unknown"
    [[ -z "$developer" ]] && developer="Unknown"
    if [[ -z "$rating" || "$rating" == "Not Rated" ]]; then
        rating="0.55"
    fi

    # Returns: title|genre|publisher|developer|players|rating|releasedate|genreid|video
    echo "${title}|${genre}|${publisher}|${developer}|${players}|${rating}|${releasedate}|${genreid}|${video}"
}

###############################################################################
# update_metadata_file
###############################################################################
update_metadata_file() {
    local base_name="$1"
    local slot_number="$2"
    local metadata_file="${SAVE_DIR}/${base_name}.state${slot_number}.metadata"

    if [[ -f /tmp/retroarch_process_stable.txt ]]; then
        local retroarch_process
        for attempt in {1..3}; do
            retroarch_process=$(grep "/opt/retropie/emulators/retroarch/bin/retroarch" /tmp/retroarch_process_stable.txt)
            if [[ -n "$retroarch_process" ]]; then
                break
            fi
            sleep 1
        done

        log_msg "RetroArch process line: $retroarch_process"
        if [[ -z "$retroarch_process" ]]; then
            log_msg "Error: No matching RetroArch process found."
            cat /tmp/retroarch_process_stable.txt >> "$LOG_FILE"
            return 1
        fi

        local core config rom_path
        core=$(echo "$retroarch_process" | awk '{for (i=1; i<=NF; i++) if ($i == "-L") print $(i+1)}')
        config=$(echo "$retroarch_process" | awk '{for (i=1; i<=NF; i++) if ($i == "--config") print $(i+1)}')
        rom_path=$(echo "$retroarch_process" | grep -oP '/home/pi/RetroPie/roms/[^"]+')
        rom_path=$(echo "$rom_path" | sed 's/ --appendconfig.*//')

        if [[ -z "$rom_path" ]]; then
            log_msg "Error: ROM path extraction failed."
            return 1
        fi
        if [[ -z "$core" || -z "$config" ]]; then
            log_msg "Error: Core or config extraction failed. core='$core', config='$config'"
            return 1
        fi

        local system_key
        system_key=$(basename "$(dirname "$config")")
        local system_name="${SYSTEM_MAP[$system_key]:-$system_key}"

        {
            echo "CORE=$core"
            echo "CONFIG=$config"
            echo "ROM=\"$rom_path\""
            echo "SYSTEM=$system_name"
        } > "$metadata_file"

        # Log to confirm the file was written (duplicated in original; retained)
        if [[ -f "$metadata_file" ]]; then
            log_msg "DEBUG: Metadata file was created at: $metadata_file"
            log_msg "DEBUG: Metadata file contents: $(cat "$metadata_file")"
        else
            log_msg "ERROR: Metadata file was NOT created at: $metadata_file"
        fi

        # Log to confirm the file was written (duplicated in original; retained)
        if [[ -f "$metadata_file" ]]; then
            log_msg "DEBUG: Metadata file was created at: $metadata_file"
            log_msg "DEBUG: Metadata file contents: $(cat "$metadata_file")"
        else
            log_msg "ERROR: Metadata file was NOT created at: $metadata_file"
        fi

        log_msg "Successfully extracted metadata => CORE=$core, CONFIG=$config, ROM=$rom_path, SYSTEM=$system_name"
        return 0
    fi

    log_msg "Error: /tmp/retroarch_process_stable.txt missing."
    return 1
}

###############################################################################
# update_gamelist
###############################################################################
update_gamelist() {
    local base_name="$1"
    local slot_number="$2"
    local screenshot_file="$3"

    # Ensure gamelist file exists
    if [[ ! -f "$GAMELIST" ]]; then
        echo '<?xml version="1.0" encoding="UTF-8"?>' > "$GAMELIST"
        echo '<gameList>' >> "$GAMELIST"
        echo '</gameList>' >> "$GAMELIST"
    fi

    # Extract system name robustly from the metadata file
    local metadata_file="${SAVE_DIR}/${base_name}.state${slot_number}.metadata"
    local system_name
    system_name=$(grep -m1 "^SYSTEM=" "$metadata_file" | cut -d '=' -f2- | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    if [[ -z "$system_name" ]]; then
        log_msg "ERROR: System name extraction failed for $metadata_file"
        return 1
    fi

    local rom_path="./${base_name}.state${slot_number}.entry"
    local rom_path_x
    rom_path_x=$(xpath_literal "$rom_path")

    local human_readable_time
    human_readable_time=$(date +"%m/%d/%Y at %I:%M%p %Z")

    local image_path="./media/images/$(basename "$screenshot_file")"

    # Log metadata file contents
    log_msg "DEBUG: Metadata file contents for '$base_name': $(cat "$metadata_file")"

    # Look up extra metadata from the original gamelist using the system name
    local extra_metadata
    extra_metadata=$(get_extra_metadata "$metadata_file")
    log_msg "DEBUG: Extracted extra metadata for '${base_name}' in system '${system_name}': ${extra_metadata}"

    local game_title genre publisher developer players rating releasedate genreid orig_video
    IFS='|' read -r game_title genre publisher developer players rating releasedate genreid orig_video <<< "$extra_metadata"

    # Clean up the title (if present) and ensure it always has something usable
    game_title=$(echo "$game_title" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -z "$game_title" ]] && game_title="$base_name"

    local display_name="${game_title} (Save Slot $slot_number)"
    local desc="Save state (slot ${slot_number}) for ${game_title} on the ${system_name} created ${human_readable_time}"

    # Ensure all fields have valid values
    [[ -z "$players" ]] && players="1"
    [[ -z "$genre" ]] && genre="Unknown"
    [[ -z "$publisher" ]] && publisher="Unknown"
    [[ -z "$developer" ]] && developer="Unknown"
    if [[ -z "$rating" || "$rating" == "Not Rated" ]]; then
        rating="0.55"
    fi

    # Optional: copy the source game's video to Save States so ES can play it from this system
    local save_video_rel=""
    if [[ -n "$orig_video" ]]; then
        local rom_abs rom_folder system_base video_src video_dst_name video_dst
        rom_abs=$(grep -m1 "^ROM=" "$metadata_file" | cut -d '=' -f2- | tr -d '"' | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

        if [[ -n "$rom_abs" ]]; then
            rom_folder=$(dirname "$rom_abs" | xargs basename)
            system_base="/home/pi/RetroPie/roms/${rom_folder}"

            if [[ "$orig_video" == /* ]]; then
                video_src="$orig_video"
            else
                video_src="${system_base}/${orig_video#./}"
            fi

            if [[ -f "$video_src" ]]; then
                video_base="$(basename "$video_src")"
                video_dst_name="$video_base"
                video_dst="${VIDEO_DIR}/${video_dst_name}"

                # Collision handling: if same filename already exists but differs, fall back to system-prefixed name
                if [[ -f "$video_dst" ]] && ! cmp -s "$video_src" "$video_dst" 2>/dev/null; then
                    video_dst_name="${rom_folder}__${video_base}"
                    video_dst="${VIDEO_DIR}/${video_dst_name}"
                fi

                # Best effort: wait until the source video stops changing size (usually already stable)
                wait_until_stable "$video_src" 2>/dev/null || true

                cp -f "$video_src" "$video_dst"
                if [[ -s "$video_dst" ]]; then
                    save_video_rel="./media/videos/${video_dst_name}"
                    log_msg "Video copied: '$video_src' -> '$video_dst'"
                else
                    log_msg "ERROR: Video copy failed (empty/missing dst): '$video_src' -> '$video_dst'"
                fi
            else
                log_msg "WARN: Original video not found: '$video_src' (orig_video='$orig_video')"
            fi
        else
            log_msg "WARN: ROM path missing in metadata; cannot resolve video source."
        fi
    fi

    log_msg "DEBUG: Final cleaned metadata - Title: '$game_title', Genre: '$genre', Publisher: '$publisher', Developer: '$developer', Players: '$players', Rating: '$rating', Video: '$save_video_rel'"
    log_msg "DEBUG: Running xmlstarlet update for:"
    log_msg "  - Path: $rom_path"
    log_msg "  - Name: $display_name"
    log_msg "  - Image: $image_path"
    log_msg "  - Desc:  $desc"
    log_msg "  - Genre: $genre"
    log_msg "  - Publisher: $publisher"
    log_msg "  - Developer: $developer"
    log_msg "  - Players: $players"
    log_msg "  - Rating: $rating"
    log_msg "  - Releasedate: $releasedate"
    log_msg "  - GenreID: $genreid"
    log_msg "  - Video: $save_video_rel"

    sleep 0.5  # Small delay to allow file operations to settle

    # Validate gamelist.xml before modifying it
    xmlstarlet fo "$GAMELIST" > /dev/null 2>&1
    if [[ $? -ne 0 ]]; then
        log_msg "ERROR: gamelist.xml is malformed before editing! Creating backup."
        cp "$GAMELIST" "${GAMELIST}.backup"
    fi

    local tmp_new="${GAMELIST}.new"
    local tmp_err="${GAMELIST}.new.err"
    : > "$tmp_err" 2>/dev/null || true

    # Check if an entry already exists for this rom_path
    if xmlstarlet sel -t -m "/gameList/game[path=$rom_path_x]" -v "path" -n "$GAMELIST" | grep -q "$rom_path"; then
        log_msg "INFO: Entry for $rom_path (slot $slot_number) already exists. Updating entry..."

        local video_count=0 releasedate_count=0 genreid_count=0
        if [[ -n "$save_video_rel" ]]; then
            video_count=$(xmlstarlet sel -t -v "count(/gameList/game[path=$rom_path_x]/video)" -n "$GAMELIST" 2>/dev/null | head -n1)
            [[ -z "$video_count" ]] && video_count=0
        fi
        if [[ -n "$releasedate" ]]; then
            releasedate_count=$(xmlstarlet sel -t -v "count(/gameList/game[path=$rom_path_x]/releasedate)" -n "$GAMELIST" 2>/dev/null | head -n1)
            [[ -z "$releasedate_count" ]] && releasedate_count=0
        fi
        if [[ -n "$genreid" ]]; then
            genreid_count=$(xmlstarlet sel -t -v "count(/gameList/game[path=$rom_path_x]/genreid)" -n "$GAMELIST" 2>/dev/null | head -n1)
            [[ -z "$genreid_count" ]] && genreid_count=0
        fi

        local -a xed_args=()
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/name" -v "$display_name")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/image" -v "$image_path")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/desc" -v "$desc")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/genre" -v "$genre")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/publisher" -v "$publisher")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/developer" -v "$developer")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/players" -v "$players")
        xed_args+=(-u "/gameList/game[path=$rom_path_x]/rating" -v "$rating")

        if [[ -n "$releasedate" ]]; then
            if [[ "$releasedate_count" -eq 0 ]]; then
                xed_args+=(-s "/gameList/game[path=$rom_path_x]" -t elem -n "releasedate" -v "$releasedate")
            else
                xed_args+=(-u "/gameList/game[path=$rom_path_x]/releasedate" -v "$releasedate")
            fi
        fi

        if [[ -n "$genreid" ]]; then
            if [[ "$genreid_count" -eq 0 ]]; then
                xed_args+=(-s "/gameList/game[path=$rom_path_x]" -t elem -n "genreid" -v "$genreid")
            else
                xed_args+=(-u "/gameList/game[path=$rom_path_x]/genreid" -v "$genreid")
            fi
        fi

        if [[ -n "$save_video_rel" ]]; then
            if [[ "$video_count" -eq 0 ]]; then
                xed_args+=(-s "/gameList/game[path=$rom_path_x]" -t elem -n "video" -v "$save_video_rel")
            else
                xed_args+=(-u "/gameList/game[path=$rom_path_x]/video" -v "$save_video_rel")
            fi
        fi

        xmlstarlet ed "${xed_args[@]}" "$GAMELIST" > "$tmp_new" 2> "$tmp_err"

        if [[ -s "$tmp_new" ]]; then
            log_msg "DEBUG: xmlstarlet successfully updated gamelist.xml"
            mv "$tmp_new" "$GAMELIST"
        else
            log_msg "ERROR: xmlstarlet did not update gamelist.xml correctly!"
            [[ -s "$tmp_err" ]] && cat "$tmp_err" >> "$LOG_FILE"
            [[ -f "$tmp_new" ]] && cat "$tmp_new" >> "$LOG_FILE"
        fi
        log_msg "SUCCESS: Updated gamelist entry for $rom_path (slot $slot_number)"
    else
        log_msg "DEBUG: '$rom_path' not found in gamelist.xml. Adding new entry..."

        local -a xed_add=()
        xed_add+=(-s "/gameList" -t elem -n "game" -v "")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "path" -v "$rom_path")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "name" -v "$display_name")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "image" -v "$image_path")
        if [[ -n "$save_video_rel" ]]; then
            xed_add+=(-s "/gameList/game[last()]" -t elem -n "video" -v "$save_video_rel")
        fi
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "desc" -v "$desc")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "genre" -v "$genre")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "publisher" -v "$publisher")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "developer" -v "$developer")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "players" -v "$players")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "rating" -v "$rating")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "releasedate" -v "$releasedate")
        xed_add+=(-s "/gameList/game[last()]" -t elem -n "genreid" -v "$genreid")

        xmlstarlet ed "${xed_add[@]}" "$GAMELIST" > "$tmp_new" 2> "$tmp_err"

        if [[ -s "$tmp_new" ]]; then
            log_msg "DEBUG: xmlstarlet successfully modified gamelist.xml"
            mv "$tmp_new" "$GAMELIST"
        else
            log_msg "ERROR: xmlstarlet did not modify gamelist.xml correctly!"
            [[ -s "$tmp_err" ]] && cat "$tmp_err" >> "$LOG_FILE"
            [[ -f "$tmp_new" ]] && cat "$tmp_new" >> "$LOG_FILE"
        fi
        log_msg "SUCCESS: Added new gamelist entry for $rom_path (slot $slot_number)"
    fi

    log_msg "DEBUG: Final gamelist.xml contents:"
    # Uncomment the following line if you wish to log the full gamelist
    # cat "$GAMELIST" >> "$LOG_FILE"

    # Cleanup: some older variants wrote xmlstarlet stderr to gamelist.xml.new.err
    rm -f "${GAMELIST}.new.err" 2>/dev/null || true
}

# Ensure the flag file exists
echo -n "0" > "$FLAG_FILE"

# Function to update the flag when a save state is detected
update_flag() {
    echo -n "1" > "$FLAG_FILE"
}

###############################################################################
# Main inotifywait Loop (wrapped so local vars remain valid)
###############################################################################
process_state_event() {
  local directory="$1" action="$2" file="$3"
    log_msg "Detected file: $file with action=$action at $(date)"
    if [[ "$file" =~ \.state([0-9]+)?$ ]]; then
		# Create the restart flag file
        touch /tmp/es-restart
		
		# Set the flag to 1
		update_flag
		
        local slot_number
        slot_number=""
        if [[ "$file" =~ \.state([0-9]+)$ ]]; then
            slot_number="${BASH_REMATCH[1]}"
        else
            slot_number="0"
        fi

        local base_name
        if [[ "$slot_number" == "0" || -z "$slot_number" ]]; then
            base_name="${file%.state}"
            slot_number="0"
        else
            base_name="${file%.state${slot_number}}"
        fi

        # Remove carriage returns and trailing spaces
        base_name="$(echo "$base_name" | tr -d '\r' | sed 's/[[:space:]]*$//')"

        local base_name_hex
        base_name_hex="$(echo -n "$base_name" | xxd -p | tr -d '\n')"
        log_msg "Processing file='$file' => base_name='$base_name' (hex=$base_name_hex), slot_number=$slot_number"

        if update_metadata_file "$base_name" "$slot_number"; then
            log_msg "DEBUG: base_name = '$base_name'"

            # Ensure source state file is fully written before copying
            wait_until_stable "$SAVE_DIR/$file"

            # Build entry file path now that base_name and slot are known
            local entry_file
            entry_file=$(printf "%s/%s.state%s.entry" "$SAVE_DIR" "$base_name" "${slot_number:-0}")
            log_msg "DEBUG: Attempting to build entry_file => '$entry_file'"
            
            cp "${SAVE_DIR}/${file}" "$entry_file"
            log_msg "Created entry file: $entry_file"
            
            local screenshot_file
            screenshot_file=$(printf "%s/%s.state%s.png" "$SCREENSHOT_DIR" "$base_name" "$slot_number")

            # Prefer RetroArch's own savestate thumbnail if available (avoids black captures on KMS/GL setups).
            # If RetroArch is configured to write thumbnails, it typically creates:
            #   ${SAVE_DIR}/${base_name}.state${slot_number}.png
            local ra_thumb="${SAVE_DIR}/${base_name}.state${slot_number}.png"

            if [[ -s "$ra_thumb" ]]; then
                cp -f "$ra_thumb" "$screenshot_file"
                if [[ -s "$screenshot_file" ]]; then
                    log_msg "Screenshot copied from RetroArch thumbnail: $ra_thumb -> $screenshot_file"
                    if [[ "$DELETE_RA_THUMB_AFTER_COPY" == "true" ]]; then
                        rm -f "$ra_thumb"
                        log_msg "Removed RetroArch thumbnail duplicate: $ra_thumb"
                    fi
                else
                    log_msg "ERROR: Thumbnail copy produced empty screenshot: $screenshot_file (source: $ra_thumb)"
                fi
            else
                # Fallback to raspi2png (may produce black images on some video drivers)
                if $RASPI2PNG -p "$screenshot_file"; then
                    log_msg "Screenshot captured via raspi2png: $screenshot_file"
                else
                    # Optional fallback to fbgrab if installed
                    if command -v fbgrab >/dev/null 2>&1; then
                        if fbgrab "$screenshot_file" >/dev/null 2>&1; then
                            log_msg "Screenshot captured via fbgrab: $screenshot_file"
                        else
                            log_msg "Failed to capture screenshot (raspi2png + fbgrab) for $file"
                        fi
                    else
                        log_msg "Failed to capture screenshot via raspi2png for $file (fbgrab not installed)"
                    fi
                fi
            fi

            local system_name
            system_name=$(grep -m1 "^SYSTEM=" "${SAVE_DIR}/${base_name}.state${slot_number}.metadata" | cut -d '=' -f2-)
            update_gamelist "$base_name" "$slot_number" "$screenshot_file" "$system_name"
        else
            log_msg "Failed to update metadata for $file. Skipping further steps."
        fi
	
    fi
}

inotifywait -m -e create -e modify --exclude '.*\.(entry|metadata|tmp|swp)$' "$SAVE_DIR" | \
while read -r directory action file; do
  process_state_event "$directory" "$action" "$file"
done
