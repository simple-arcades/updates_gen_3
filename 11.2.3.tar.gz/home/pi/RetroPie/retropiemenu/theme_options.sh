#!/bin/bash

# Global Constants
MUSIC_FOLDER="/home/pi/RetroPie/music"
SCREENSAVER_FOLDER="/opt/retropie/configs/all/emulationstation/scripts/videos/screensavers"
ES_CONFIG_FILE="/opt/retropie/configs/all/emulationstation/es_settings.cfg"
SELECTED_PLAYLIST_FILE="/home/pi/music_settings/selected_playlist.flag"
SCREENSAVER_CONFIG="$SCREENSAVER_FOLDER/selected_screensavers.conf"
THEME_FOLDER="/etc/emulationstation/themes"
MUTE_LAUNCH_SOUND_FLAG="/home/pi/music_settings/mute_launch_sound.flag"
SCREENSAVER_MUSIC_FLAG="/home/pi/music_settings/music_over_screensaver/onoff.flag"
LAUNCH_VIDEO_MODE_FLAG="/home/pi/music_settings/launch_video_mode.flag"

# Reboot is required only for certain visual changes (applied on exit)
NEED_REBOOT=0

# Ensure Required Files Exist
# Ensure Required Files Exist
ensure_required_files() {
    # Base builds already include the folders; we only ensure the flag/config files exist.
    if [[ ! -f "$LAUNCH_VIDEO_MODE_FLAG" ]]; then
        echo "0" > "$LAUNCH_VIDEO_MODE_FLAG"
    fi
    for file in "$SELECTED_PLAYLIST_FILE" "$SCREENSAVER_CONFIG" "$MUTE_LAUNCH_SOUND_FLAG" "$SCREENSAVER_MUSIC_FLAG"; do
        [[ ! -f "$file" ]] && touch "$file"
    done
}
ensure_required_files


# Helper Functions
show_message() {
    dialog --ok-button "OK" --msgbox "$1" 10 40
}

update_flag() {
    echo "$2" > "$1"
}

get_flag_value() {
    cat "$1" 2>/dev/null || echo "$2"
}

###############################################
# Intro screen for Simple Arcades Theme Options Script
###############################################
function intro_screen() {
    local intro_message="Welcome to the Simple Arcades Theme Options Tool!

This tool allows you to:
 - Customize the UI theme of your Simple Arcade.
 - Manage screensaver settings.
 - Configure background music playlists.
 - Adjust game launch video settings.

**Important:**
 - Some settings changes will require a reboot before changes apply.

Use the menu to navigate and select your desired options.

Press OK to continue and customize your Simple Arcade setup."
    
    dialog --backtitle "Simple Arcades Theme Options Utility" \
           --title "Simple Arcades Theme Options Utility" \
           --msgbox "$intro_message" 20 80
}

# Main Menu
main_menu() {
    while true; do
        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Simple Arcades Theme Options" --menu "Choose an option:" 20 80 6 \
            1 "UI Theme Settings" \
            2 "Screensaver Settings" \
            3 "Music Settings" \
            4 "Game Launch Video Settings" \
            3>&1 1>&2 2>&3)

        case $? in
            0)
                case $OPTION in
                    1) ui_theme_settings ;;
                    2) screensaver_settings ;;
                    3) music_settings ;;
                    4) launch_video_settings ;;
                esac
                ;;
        *)
            if [[ "$NEED_REBOOT" -eq 1 ]]; then
                prompt_reboot_if_needed || continue
            fi
            show_message "Done. Now go play some games! :)"
            exit 0
            ;;
        esac
    done
}

# UI Theme Settings
ui_theme_settings() {
    while true; do
        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "UI Theme Settings" --menu "Choose an option:" 15 60 2 \
            1 "View/Change Theme" \
            2 "Show/Hide Support QR Code" \
            3>&1 1>&2 2>&3)

        case $? in
            0)
                case $OPTION in
                    1) view_change_theme ;;
                    2) toggle_qr_code ;;
                esac
                ;;
            *) return ;;
        esac
    done
}

# Theme changes 
view_change_theme() {
    local THEME_LIST=$(find "$THEME_FOLDER" -mindepth 1 -maxdepth 1 -type d | sort)
    [[ -z $THEME_LIST ]] && { show_message "No themes found in $THEME_FOLDER!"; return; }

    local CURRENT_THEME=$(sed -n 's/.*<string name="ThemeSet" value="\([^"]*\)".*/\1/p' "$ES_CONFIG_FILE")
    local MENU_OPTIONS=()
    local COUNTER=1

    while IFS= read -r THEME_PATH; do
        local THEME_NAME=$(basename "$THEME_PATH")
        local MARK=$([[ $CURRENT_THEME == "$THEME_NAME" ]] && echo " (Currently Selected)")
        MENU_OPTIONS+=("$COUNTER" "$THEME_NAME$MARK")
        ((COUNTER++))
    done <<< "$THEME_LIST"

    local THEME_TAG=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Change UI Theme" --menu "Choose a theme:" 15 60 10 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

    # Return if the user cancels
    [[ $? -ne 0 ]] && return

    local SELECTED_THEME=$(echo "$THEME_LIST" | sed -n "${THEME_TAG}p" | xargs basename)
    if [[ $CURRENT_THEME != "$SELECTED_THEME" ]]; then
        sed -i "s|<string name=\"ThemeSet\" value=\".*\"|<string name=\"ThemeSet\" value=\"$SELECTED_THEME\"|" "$ES_CONFIG_FILE"
        show_message "Theme applied! A reboot is required to see the changes."
    NEED_REBOOT=1
    else
        show_message "The selected theme is already applied. No reboot is required."
    fi
}

# Hide the QR code via toggling the image shown
toggle_qr_code() {
    local XML_FILE="/etc/emulationstation/themes/Retro Console (Default)/style/snes_usa.xml"

    # Check if user has sudo privileges
    if ! sudo -n true 2>/dev/null; then
        show_message "This action requires sudo privileges. Please re-run the script with sudo."
        return
    fi

    # Detect current QR code state
    local CURRENT_STATUS
    if sudo grep -q '<path>.*sa_support_page_qr_code.png</path>' "$XML_FILE"; then
        CURRENT_STATUS="1" # QR Code is visible
    else
        CURRENT_STATUS="0" # QR Code is hidden
    fi

    # Set menu option based on current status
    local MENU_OPTION=$([[ $CURRENT_STATUS == "1" ]] && echo "Hide Support QR Code (Currently Visible)" || echo "Show Support QR Code (Currently Hidden)")

    # Display menu and handle selection
    local OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Show/Hide Support QR Code" --menu \
        "Toggle the visibility of the support QR code:" 15 60 1 \
        1 "$MENU_OPTION" \
        3>&1 1>&2 2>&3)

    # Return if the user cancels
    [[ $? -ne 0 ]] && return

    # Toggle QR code visibility and provide feedback
    if [[ $CURRENT_STATUS == "1" ]]; then
        sudo sed -i 's|<path>.*sa_support_page_qr_code.png</path>|<path>./../art/blank_qr_code.png</path>|' "$XML_FILE"
        show_message "Support QR code has been hidden. A reboot is required to apply changes."
    else
        sudo sed -i 's|<path>.*blank_qr_code.png</path>|<path>./../art/sa_support_page_qr_code.png</path>|' "$XML_FILE"
        show_message "Support QR code is now visible. A reboot is required to apply changes."
    fi

    # Reboot confirmation
    NEED_REBOOT=1
}

# Confirm and reboot after any visual theme changes
prompt_reboot_if_needed() {
    if [[ "$NEED_REBOOT" -eq 1 ]]; then
        dialog --yes-label "Reboot" --no-label "Back" --yesno "Changes were made that require a reboot to take effect.\n\nSelect Reboot to restart now." 10 60
        if [[ $? -eq 0 ]]; then
            dialog --ok-button "OK" --msgbox "Rebooting now to apply changes..." 7 40
            sudo reboot
        else
            return 1
        fi
    fi
    return 0
}


# Screensaver Settings
screensaver_settings() {
    while true; do
        MUSIC_STATUS=$(get_flag_value "$SCREENSAVER_MUSIC_FLAG" 0)
        MUSIC_OPTION=$([[ $MUSIC_STATUS == "1" ]] && echo "Disable Screensaver Music" || echo "Enable Screensaver Music")

        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Screensaver Settings" --menu "Choose an option:" 15 60 2 \
            1 "Screensaver Gallery (Edit Video List)" \
            2 "$MUSIC_OPTION" \
            3>&1 1>&2 2>&3)

        [[ $? -ne 0 ]] && return

        case $OPTION in
            1) screensaver_video_settings ;;
            2)
                NEW_STATUS=$([[ $MUSIC_STATUS == "1" ]] && echo "0" || echo "1")
                update_flag "$SCREENSAVER_MUSIC_FLAG" "$NEW_STATUS"
                show_message "Screensaver music has been $([[ $NEW_STATUS == "1" ]] && echo "enabled" || echo "disabled")."
                ;;
        esac
    done
}

screensaver_video_settings() {
    if [[ ! -d "$SCREENSAVER_FOLDER" ]]; then
        show_message "Screensaver folder not found: $SCREENSAVER_FOLDER"
        return
    fi

    # If config is missing or empty, default to all videos.
    if [[ ! -s "$SCREENSAVER_CONFIG" ]]; then
        > "$SCREENSAVER_CONFIG"
        for video in "$SCREENSAVER_FOLDER"/*.mp4; do
            echo "$(basename "$video")" >> "$SCREENSAVER_CONFIG"
        done
        show_message "Screensaver config was empty. Auto-populated with all available videos."
    fi

    while true; do
        # Tag -> filename map so we save filenames (not numeric tags)
        declare -A TAG_TO_FILE=()

        MENU_OPTIONS=("SelectAll" "Select All Videos" "off")
        COUNTER=1

        # Populate MENU_OPTIONS with videos
        for video in "$SCREENSAVER_FOLDER"/*.mp4; do
            FILENAME=$(basename "$video")
            if grep -Fxq "$FILENAME" "$SCREENSAVER_CONFIG" 2>/dev/null; then
                SELECTED="on"
            else
                SELECTED="off"
            fi
            TAG="$COUNTER"
            TAG_TO_FILE["$TAG"]="$FILENAME"
            MENU_OPTIONS+=("$TAG" "$FILENAME" "$SELECTED")
            ((COUNTER++))
        done

        CHOICES=$(dialog --ok-button "Select" --cancel-button "Cancel"             --title "Screensaver Video Selection" --checklist             "Use your controls as follows:

Back Button = check highlighted selection.
Select Button = save and confirm choice.
"             25 67 15 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)

        [[ $? -ne 0 ]] && return

        if echo "$CHOICES" | grep -q "SelectAll"; then
            > "$SCREENSAVER_CONFIG"
            for video in "$SCREENSAVER_FOLDER"/*.mp4; do
                echo "$(basename "$video")" >> "$SCREENSAVER_CONFIG"
            done
            show_message "All videos selected!"
            return
        else
            > "$SCREENSAVER_CONFIG"
            SELECTED_TAGS=$(echo "$CHOICES" | tr -d '"')
            for tag in $SELECTED_TAGS; do
                if [[ -n "${TAG_TO_FILE[$tag]}" ]]; then
                    echo "${TAG_TO_FILE[$tag]}" >> "$SCREENSAVER_CONFIG"
                fi
            done
            show_message "Screensaver video selection updated!"
            return
        fi
    done
}

launch_video_settings() {
    while true; do
        CURRENT_STATUS=$(get_flag_value "$MUTE_LAUNCH_SOUND_FLAG" 0)
        CURRENT_MODE=$(get_flag_value "$LAUNCH_VIDEO_MODE_FLAG" 0)
        
        # Determine text for the launch video sound toggle option.
        if [ "$CURRENT_STATUS" == "1" ]; then
            mute_text="Enable Launch Video Sound (Currently Muted)"
        else
            mute_text="Mute Launch Video Sound (Currently Enabled)"
        fi

        # Main options: change sound setting, select video mode, or go back.
        MENU_OPTIONS=(
            1 "$mute_text"
            2 "Set Launch Video Mode"
            3 "Back to Main Menu"
        )
        
        OPTION=$(dialog --ok-button "Select" --cancel-button "Back" \
            --title "Launch Video Settings" \
            --menu "Configure launch video options:" 20 70 3 "${MENU_OPTIONS[@]}" \
            3>&1 1>&2 2>&3)
        [[ $? -ne 0 ]] && break
        
        case $OPTION in
            1)
                # Toggle the mute status.
                NEW_STATUS=$([[ $CURRENT_STATUS == "1" ]] && echo "0" || echo "1")
                update_flag "$MUTE_LAUNCH_SOUND_FLAG" "$NEW_STATUS"
                show_message "Launch video sound has been $([[ $NEW_STATUS == "1" ]] && echo "muted" || echo "enabled")."
                ;;
            2)
                # Allow the user to select one of the three launch video modes.
                MODE_OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" \
                    --radiolist "Select Launch Video Mode:

Back Button = check highlighted selection.
Select Button = save and confirm choice." 20 70 3 \
                    0 "Random Helper Videos" $([ "$CURRENT_MODE" == "0" ] && echo "on" || echo "off") \
                    1 "Standard Loading Video" $([ "$CURRENT_MODE" == "1" ] && echo "on" || echo "off") \
                    2 "System-Specific Helper Videos" $([ "$CURRENT_MODE" == "2" ] && echo "on" || echo "off") \
                    3>&1 1>&2 2>&3)
                if [ $? -eq 0 ]; then
                    update_flag "$LAUNCH_VIDEO_MODE_FLAG" "$MODE_OPTION"
                    case $MODE_OPTION in
                        0) show_message "Random Helper Videos selected." ;;
                        1) show_message "Standard Loading Video selected." ;;
                        2) show_message "System-Specific Helper Videos selected." ;;
                    esac
                fi
                ;;
            3)
                break
                ;;
        esac
    done
}

# Music Settings
music_settings() {
    while true; do
        MENU_OPTIONS=("NoMusic" "No Music (Disable Background Music)")
        COUNTER=1

        FOLDER_LIST=$(find "$MUSIC_FOLDER" -mindepth 1 -maxdepth 1 -type d | sort)
        [[ -z $FOLDER_LIST ]] && { show_message "No playlists found in $MUSIC_FOLDER!"; return; }

        CURRENT_PLAYLIST=$(get_flag_value "$SELECTED_PLAYLIST_FILE" "")
        CURRENT_MUSIC_ONOFF=$(get_flag_value "/home/pi/music_settings/onoff.flag" "1")

        while IFS= read -r FOLDER; do
            FOLDER_NAME=$(basename "$FOLDER")
            MARK=$([[ $CURRENT_PLAYLIST == "$FOLDER" ]] && echo " (Currently Selected)")
            MENU_OPTIONS+=("$COUNTER" "$FOLDER_NAME$MARK")
            ((COUNTER++))
        done <<< "$FOLDER_LIST"

        PLAYLIST_TAG=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "Soundtrack Selection" --menu "Choose a music playlist:" 20 70 15 "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)
        [[ $? -ne 0 ]] && return

        if [ "$PLAYLIST_TAG" == "NoMusic" ]; then
            update_flag "/home/pi/music_settings/onoff.flag" "0"
            pkill mpg123
            show_message "Background music disabled."
            continue
        fi

        SELECTED_FOLDER=$(echo "$FOLDER_LIST" | sed -n "${PLAYLIST_TAG}p")

        # Always re-enable music when a playlist is selected (even if it's the same playlist as before).
        # Otherwise, choosing "No Music" once could leave music disabled even after selecting a playlist.
        update_flag "/home/pi/music_settings/onoff.flag" "1"

        # Restart the player if the playlist changed, music was previously disabled, or no mpg123 process exists.
        if [[ $CURRENT_PLAYLIST != "$SELECTED_FOLDER" ]] || [[ "$CURRENT_MUSIC_ONOFF" == "0" ]] || ! pgrep -x mpg123 >/dev/null 2>&1; then
            update_flag "$SELECTED_PLAYLIST_FILE" "$SELECTED_FOLDER"
            restart_music_player "$SELECTED_FOLDER"
        fi
    done
}

restart_music_player() {
    pkill mpg123
    sleep 1
    if ! ls "$1"/*.mp3 >/dev/null 2>&1; then
        show_message "No .mp3 files found in $1. Music not restarted."
        return
    fi
    mpg123 -Z "$1"/*.mp3 > /dev/null 2>&1 &
    pkill -STOP mpg123
    show_message "Playlist updated!"
}



# Run Main Menu
intro_screen
main_menu