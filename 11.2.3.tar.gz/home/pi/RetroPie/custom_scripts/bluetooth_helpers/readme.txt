these files are included from http://git.kernel.org/cgit/bluetooth/bluez.git/tree/test

