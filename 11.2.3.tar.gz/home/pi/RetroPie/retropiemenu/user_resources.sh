#!/bin/bash

# Set the log flag for user resources logging.
# Set ENABLE_LOGS="true" to enable logging; otherwise, set to "false" to disable.
ENABLE_LOGS="false"

# Paths
HOW_TO_VIDEOS_FOLDER="/home/pi/RetroPie/docs/videos"
LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/user_resources.log"

# Helper Functions
show_message() {
    # Just an OK button for informational messages
    dialog --ok-button "OK" --msgbox "$1" 10 50
}

safe_exit() {
    show_message "Exiting User Resources Menu. Enjoy your arcade!"
    exit 0
}

log_error() {
    if [ "$ENABLE_LOGS" = "true" ]; then
        echo "$(date): $1" >> "$LOG_FILE"
    fi
}

###############################################
# Intro screen for User Resources Script
###############################################
function intro_screen() {
    local intro_message="Welcome to the Simple Arcades User Resources Tool!

This tool allows you to:

 - View your arcade's user manual URL.
 - Play helpful how-to videos.

Use the menu to navigate and select your desired options.

Press OK to continue and access your user resources."
    
    dialog --backtitle "Simple Arcades User Resources Tool" \
           --title "Simple Arcades User Resources Tool" \
           --msgbox "$intro_message" 20 80
}

# View User Manual Link
view_user_manual() {
    show_message "View your arcade's manual at: https://www.simple-arcades.com/users-manual/"
}

# Play How-To Videos
play_how_to_videos() {
    if [[ ! -d "$HOW_TO_VIDEOS_FOLDER" ]]; then
        log_error "How-to videos folder not found at $HOW_TO_VIDEOS_FOLDER."
        show_message "How-to videos folder not found. Please contact support."
        return
    fi

    # Loop until the user cancels out of the video list.
    while true; do
        MENU_OPTIONS=()
        COUNTER=1

        # Build the menu options from available .mp4 files.
        for video in "$HOW_TO_VIDEOS_FOLDER"/*.mp4; do
            [[ -f "$video" ]] || continue
            MENU_OPTIONS+=("$COUNTER" "$(basename "${video%.*}")")
            ((COUNTER++))
        done

        if [[ 12 -eq 0 ]]; then
            log_error "No videos found in $HOW_TO_VIDEOS_FOLDER."
            show_message "How-to videos coming soon!"
            return
        fi

        # Show the dialog menu and capture its output and exit status.
        dialog_output=$(dialog --backtitle "How-To Videos" \
                                --title "How-To Videos" \
                                --ok-button "Play" \
                                --cancel-button "Back" \
                                --menu "Select a video to play:" 15 50 ${#MENU_OPTIONS[@]} \
                                "${MENU_OPTIONS[@]}" 3>&1 1>&2 2>&3)
        ret=$?

        # If the user pressed Cancel (Back), exit back to the main menu.
        if [[ $ret -ne 0 ]]; then
            break
        fi

        OPTION="$dialog_output"

        # Calculate the selected video's filename (without extension).
        SELECTED_VIDEO="${MENU_OPTIONS[((OPTION-1)*2)+1]}"

        clear
        # Launch the video with omxplayer.
        # Redirecting stdin from /dev/null prevents stray key presses from being passed along.
        omxplayer -b "$HOW_TO_VIDEOS_FOLDER/$SELECTED_VIDEO.mp4" </dev/null > /dev/null 2>&1
        if [[ $? -ne 0 ]]; then
            log_error "Failed to play video: $SELECTED_VIDEO."
            show_message "An error occurred while playing the video. Please contact support."
        fi
        clear
        # After the video finishes, the loop re-displays the video list.
    done
}



# User Resources Menu
user_resources_menu() {
    while true; do
        OPTION=$(dialog --ok-button "Select" --cancel-button "Cancel" --title "User Resources" --menu "Choose an option:" 15 50 3 \
            1 "View User Manual" \
            2 "Play How-To Videos" \
            3 "Exit" \
            3>&1 1>&2 2>&3)

        if [[ $? -ne 0 ]]; then
            # User pressed Cancel at the top level menu, which can also exit
            safe_exit
        fi

        case $OPTION in
            1) view_user_manual ;;
            2) play_how_to_videos ;;
            3) safe_exit ;;
            *) safe_exit ;;
        esac
    done
}

# Start Menu
intro_screen
user_resources_menu