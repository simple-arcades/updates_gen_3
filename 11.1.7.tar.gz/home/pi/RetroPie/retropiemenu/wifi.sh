#!/bin/bash

# Ensure the script is run as root
sudo /home/pi/RetroPie/custom_scripts/wifi_setup_running_es_only.sh 2>/dev/null