#!/bin/bash
# onend.sh
#
# This script is run at the end of an EmulationStation session.
# It kills auxiliary processes, performs cleanup actions, and resumes music.
#

export PYTHONPATH=/usr/lib/python3/dist-packages:$PYTHONPATH

# Global logging flag:
ENABLE_LOG="false"    # Set to "false" to disable debug logging
FLAG_FILE="/home/pi/RetroPie/custom_scripts/logs/save_state_flag.txt"

LOG_FILE="/home/pi/RetroPie/custom_scripts/logs/onend_debug.log"
if [ "$ENABLE_LOG" = "true" ]; then
    > "$LOG_FILE"
fi

log_debug() {
    if [ "$ENABLE_LOG" = "true" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [onend.sh] $1" >> "$LOG_FILE"
    fi
}

log_debug "onend.sh script started."

#####################################
# Determine whether to skip extra actions.
#####################################
SKIP_EXTRA="false"
if [ -f /tmp/skip_extras ]; then
    SKIP_EXTRA="true"
    log_debug "Marker file /tmp/skip_extras found: skipping exit video, orphan cleanup, check_recycle_bin, flag reset, and ES restart."
    # Remove the marker file so it doesn't affect future sessions.
    rm /tmp/skip_extras
fi

#####################################
# Extra onend actions (only if SKIP_EXTRA is false)
#####################################
if [ "$SKIP_EXTRA" != "true" ]; then
	
	#####################################
	# Kill auxiliary processes (always done)
	#####################################
	log_debug "Killing auxiliary processes..."
	pkill -f "/home/pi/RetroPie/custom_scripts/watcher_script.sh" > /dev/null 2>&1 && log_debug "Killed watcher_script.sh."
	pkill -f "while true; do ps aux | grep \"\[r\]etroarch\"" > /dev/null 2>&1 && log_debug "Killed RetroArch process monitor."
	pkill -f "inotifywait -m -e create /home/pi/RetroPie/roms/savestates" > /dev/null 2>&1 && log_debug "Killed inotifywait process."

    flag_value=$(sed -e 's/^[[:space:]]*//;s/[[:space:]]*$//' "$FLAG_FILE")

    if [[ -f "$FLAG_FILE" && "$flag_value" == "1" ]]; then
        log_debug "Starting orphan cleanup."
        SAVE_DIR="/home/pi/RetroPie/roms/savestates"
        GAMELIST="${SAVE_DIR}/gamelist.xml"
        if [[ ! -f "$GAMELIST" ]]; then
            log_debug "No gamelist.xml found at $GAMELIST - nothing to clean."
        else
            while IFS= read -r path; do
                if [[ -n "$path" ]]; then
                    local_file="${SAVE_DIR}/${path##*/}"
                    log_debug "Checking path: $path => local file: $local_file"
                    if [[ ! -f "$local_file" ]]; then
                        log_debug "Removing orphaned entry for path: $path"
                        xmlstarlet ed --inplace -d "/gameList/game[path='$path']" "$GAMELIST" \
                            || log_debug "ERROR: Failed to remove orphaned entry for path: $path"
                    fi
                fi
            done < <(xmlstarlet sel -t -m "/gameList/game/path" -v "." -n "$GAMELIST")
            log_debug "Orphan cleanup completed."
        fi

        #nohup bash -c '/home/pi/RetroPie/custom_scripts/check_recycle_bin.sh' > /dev/null 2>&1
		
		omxplayer -b "/opt/retropie/configs/all/emulationstation/scripts/videos/exit_game_save.mp4" > /dev/null 2>&1 &
		
		log_debug "Flag file indicates a save state was created; calling restart_emulationstation.py script."
        python3 /home/pi/RetroPie/custom_scripts/restart_emulationstation.py > /dev/null 2>&1 &
				
		
		#exit 

	else
        log_debug "Flag file indicates no save state. Playing default exit video."
        omxplayer -b "/opt/retropie/configs/all/emulationstation/scripts/videos/exit.mp4" > /dev/null 2>&1 &
    fi

else
    log_debug "SKIP_EXTRA is true: Skipping exit video, orphan cleanup, check_recycle_bin, flag reset, and ES restart."
fi

echo -n "0" > "$FLAG_FILE"

#####################################
# Resume music if configured.
#####################################
if [[ $(cat /home/pi/music_settings/onoff.flag) == "1" ]]; then
    log_debug "Resuming music player (pkill -CONT mpg123)."
    pkill -CONT mpg123
fi

log_debug "onend.sh script completed."
